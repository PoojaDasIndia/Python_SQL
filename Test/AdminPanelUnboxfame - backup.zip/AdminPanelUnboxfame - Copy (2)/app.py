from mysql.connector import Error
from flask import Flask, render_template, request, redirect, flash, session
import mysql.connector as con
import secrets

# from flask_tinymce import TinyMCE

secret_key = secrets.token_hex(16)
# print(secret_key)

app = Flask(__name__)
app.secret_key = secret_key

# Database connection configuration
db_config = {
    'host': 'localhost',
    'database': 'Unboxfamedata',
    'user': 'root',
    'password': ''
}

db_config_category = {
    'host': 'localhost',
    'database': 'categorydata',
    'user': 'root',
    'password': ''
}


def connection_db():
    try:
        mydb = con.connect(host='localhost',
                           user='root',
                           password='',
                           database='Unboxfamedata')
        print(f"Connected with database Unboxfamedata established successfully...")
    except ConnectionError:
        print("Error while connecting to database: %s" % ConnectionError)
        raise ConnectionError
    return mydb


def insert(table_name, field):
    try:
        print(f'Inserting start on table {table_name}')
        # mydb = connection_db()
        connection = con.connect(**db_config)

        query = f"INSERT INTO users VALUES {field}"
        cursor = connection.cursor()
        cursor.execute(query)
        connection.commit()
        cursor.close()
        connection.close()
        print(f"Insertion done on table uses ")
    except Error as e:
        print("Error connecting to MySQL database:", e)


def authenticate(username):
    try:
        connection = con.connect(**db_config)
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()
        cursor.close()
        connection.close()
        return user
    except Error as e:
        print("Error connecting to MySQL database:", e)
        return None


def user_exists(username):
    # Connect to the MySQL database
    db = connection_db()
    # Create a cursor to execute SQL queries
    cursor = db.cursor()

    # Prepare the SQL query to check if the user exists
    query = "SELECT COUNT(*) FROM users WHERE username = %s"
    cursor.execute(query, (username,))

    # Fetch the result
    result = cursor.fetchone()

    # Close the database connection
    cursor.close()
    db.close()

    # Check if the user count is greater than 0
    if result and result[0] > 0:
        return True
    else:
        return False


# ______________________________________________ || LOGIN ||_____________________________________________________________

# ********************************************* First page *******************************************
# Define a route to render the HTML form
@app.route("/")
def index():
    return render_template("login.html")


# ********************************************* Login PAGE*****************************************
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    user = authenticate(username)

    if user:
        if password == user['password']:
            role = user['role']
            user_type = user['user_type']

            if role == 'Data_Entry' and user_type == 'Brand_Name':
                session['username'] = username
                return redirect('/brand_name_data_entry_dashboard')

            elif role == 'Manager' and user_type == 'Brand_Name':
                session['username'] = username
                return redirect('/brand_name_manager_dashboard')

            elif role == 'Page_Editor' and user_type == 'Page_modification':
                session['username'] = username
                return redirect('/page_modification_page_editor_dashboard')

            elif role == 'Page_Manager' and user_type == 'Page_modification':
                session['username'] = username
                return redirect('/page_modification_page_manager_dashboard')

            elif role == 'Super_admin' and user_type == 'Super_admin':
                session['username'] = username  # Store the username in the session
                return redirect('/dashboard')

    flash('Invalid username or password', 'error')
    return redirect('/')


# ______________________________________________ || DASHBOARD ||_____________________________________________________________

# ********************************************* Add user ***************************************
@app.route("/add_user", methods=["POST"])
def add_user():
    username = request.form["username"]
    firstname = request.form["firstname"]
    lastname = request.form["lastname"]
    email = request.form["email"]
    password = request.form["password"]
    user_type = request.form["user_type"]
    role = request.form["role"]
    try:
        # Check if the user already exists in the database
        if user_exists(username):
            flash('User already exists!', 'error')
        else:
            # Store data in MySQL database
            values = (username, firstname, lastname, email, password, user_type, role)
            insert(table_name='users', field=values)
            flash('User created successfully!', 'success')

    except Exception as e:
        flash('An error occurred: {}'.format(str(e)), 'error')

    return redirect("/dashboard")


# *********************************************** All User ***********************************************
def alluser():
    # all user from the database
    connection = con.connect(**db_config)
    cursor = connection.cursor()
    select_query = f'SELECT * FROM users'
    cursor.execute(select_query)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    return result


def allpage():
    connection = con.connect(**db_config)
    cursor = connection.cursor()
    select_query = f'SELECT * FROM pages'
    cursor.execute(select_query)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    return result


def allCategorypage():
    connection = con.connect(**db_config)
    cursor = connection.cursor()
    select_query = f'SELECT category FROM pages'
    cursor.execute(select_query)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    return result


@app.route('/dashboard')
def dashboard():
    username = session.get('username')  # Retrieve the username from the session
    records = alluser()
    page_all = allpage()
    allCategory = allCategorypage()
    category_list = table_list()

    if username:
        if records:
            if page_all:
                if allCategory:
                    # Retrieve the first record from the list
                    record = records
                    page = page_all
                    category_all = allCategory
                    # Pass the record to the template for rendering
                    return render_template("dashboard.html", page=page, category_all=category_all, record=record,
                                           category_list=category_list,
                                           username=username)

    # Handle the case when no records are found or username is not set
    return redirect('/')


# ************************************ Edit User **********************************************
@app.route('/edit_user', methods=['POST'])
def edit_database():
    username = request.form["edit-username"]
    firstname = request.form["edit-firstname"]
    lastname = request.form["edit-lastname"]
    email = request.form["edit-email"]
    password = request.form["edit-password"]
    user_type = request.form["edit-user-type"]
    role = request.form["edit-role"]

    connection = con.connect(**db_config)
    cursor = connection.cursor()
    select_query = f"""UPDATE users SET firstname ='{firstname}',
                                        lastname='{lastname}',
                                        email='{email}',
                                        password='{password}',
                                        user_type='{user_type.replace(" ", "_")}',
                                        role='{role.replace(" ", "_")}'
                where username='{username}'"""
    cursor.execute(select_query)

    connection.commit()
    cursor.close()

    flash('User Update successfully!', 'success')

    return redirect("/dashboard")


# ********************************** Delete User *************************************************

@app.route('/delete_user', methods=['POST'])
def delete_user():
    username = request.form.get('username')
    # Delete user from the database
    connection = con.connect(**db_config)
    cursor = connection.cursor()
    delete_query = f'DELETE FROM users WHERE username = "{username}"'
    cursor.execute(delete_query)
    connection.commit()
    cursor.close()
    flash('User deleted successfully!', 'success')
    return redirect("/dashboard")


# ***************************************** Add Brand Name ********************************************************#
def create_table(table_name):
    cnx = con.connect(**db_config_category)
    cursor = cnx.cursor()

    # Check if the table already exists
    cursor.execute(f"SHOW TABLES LIKE '{table_name}'")
    table_exists = cursor.fetchone()

    # If the table doesn't exist, create it
    if not table_exists:
        create_table_query = f"""
        CREATE TABLE {table_name} (
            Brand_Name VARCHAR(100),
            Description VARCHAR(500),
            Tagline VARCHAR(100),
            Domain_availability VARCHAR(50),
            Trademark_availability VARCHAR(50)
        )
        """
        cursor.execute(create_table_query)
        cnx.commit()
        return True

    cursor.close()
    cnx.close()
    return False


def table_list():
    cnx = con.connect(**db_config_category)
    cursor = cnx.cursor()

    # Check if the table already exists
    cursor.execute(f"SHOW TABLES;")
    table_exist = cursor.fetchall()
    cursor.close()
    cnx.close()
    table_list_all = [col.capitalize().replace('and', '&').replace('_', ' ') for row in table_exist for col in row]

    return table_list_all


def insert_data(table_name, Brand_Name, description, tagline, domainAvailability, trademarkAvailability):
    cnx = con.connect(**db_config_category)
    cursor = cnx.cursor()

    # Insert data into the table
    insert_data_query = f"""
    INSERT INTO {table_name} (Brand_Name, Description, tagline, Domain_availability, Trademark_availability)
    VALUES (%s, %s, %s, %s, %s)
    """
    data_values = (Brand_Name, description, tagline, domainAvailability, trademarkAvailability)
    cursor.execute(insert_data_query, data_values)
    cnx.commit()
    cursor.close()
    cnx.close()


@app.route('/add_brand_name', methods=['GET', 'POST'])
def add_brand_name():
    if request.method == 'POST':
        # Get form data
        table_name = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')
        Brand_Name = request.form['brandName'].capitalize()
        description = request.form['description'].capitalize()
        tagline = request.form['tagline'].capitalize()
        domainAvailability = request.form['domainAvailability']
        trademarkAvailability = request.form['trademarkAvailability']

        try:
            # Insert data into the table
            insert_data(table_name, Brand_Name, description, tagline, domainAvailability,
                        trademarkAvailability)

            flash(
                f"Data inserted into table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully.",
                'success')
        except:
            flash(f"'{table_name.capitalize().replace('and', '&').replace('_', ' ')}' not present", 'error')

        return redirect('/dashboard')

    return redirect('/dashboard')


# ********************************************** Add Category **********************************************************

@app.route('/add_category', methods=['GET', 'POST'])
def add_category():
    if request.method == 'POST':
        table_name = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')
        # Create table if it doesn't exist
        table_created = create_table(table_name)

        if table_created:
            flash(f"Table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' created successfully",
                  'success')
        else:
            flash(f"Table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' already Exit", 'error')

        return redirect('/dashboard')

    return redirect('/dashboard')


# **************************************** Edit Brand Name error ********************************************************
def brand_name_list(table_name):
    cnx = con.connect(**db_config_category)
    cursor = cnx.cursor()

    # Check if the table already exists
    cursor.execute(f"SELECT * FROM {table_name};")
    brandName_list = cursor.fetchall()
    cursor.close()
    cnx.close()
    # Extract brand_name and domain from the fetched results
    brand_name = [row[0] for row in brandName_list]
    Description = [row[1] for row in brandName_list]
    Tagline = [row[2] for row in brandName_list]
    Domain_availability = [row[3] for row in brandName_list]
    Trademark_availability = [row[4] for row in brandName_list]

    return brand_name, Description, Tagline, Domain_availability, Trademark_availability


@app.route('/edit_dashboard', methods=['GET', 'POST'])
def edit_brand_name():
    if request.method == 'POST':
        table_name = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')
        # Create table if it doesn't exist
        brand_name, Description, Tagline, Domain_availability, Trademark_availability = brand_name_list(table_name)

        return render_template("dashboard.html", brand_list=brand_name)


# **************************************** Page Editor *******************************************************
@app.route('/page_editor', methods=['GET', 'POST'])
def page_editor():
    if request.method == 'POST':
        # Get form data
        table_name = 'pages'
        category = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')

        title = request.form['Title']
        description = request.form['Description']
        keywords = request.form['Keywords']
        otherMeta = request.form['Other_Meta']
        mainBlock = request.form['Main_block']
        question1 = request.form['Question1']
        answer1 = request.form['Answer1']
        question2 = request.form['Question2']
        answer2 = request.form['Answer2']
        question3 = request.form['Question3']
        answer3 = request.form['Answer3']
        question4 = request.form['Question4']
        answer4 = request.form['Answer4']
        question5 = request.form['Question5']
        answer5 = request.form['Answer5']

        field = (
            category, title, description, keywords, otherMeta, mainBlock, question1, answer1, question2, answer2,
            question3, answer3, question4, answer4,
            question5,
            answer5)

        connection = con.connect(**db_config)
        cursor = connection.cursor()

        select_query = f"SELECT * FROM pages WHERE category = '{category}';"
        cursor.execute(select_query)
        category_SEL = cursor.fetchone()

        if category_SEL is None:
            query = f'INSERT INTO pages VALUES {field} '
            cursor.execute(query)
            connection.commit()
            cursor.close()
            flash(
                f"Insert on '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully.",
                'success')

        else:
            # Update data in the table
            query_del = f"DELETE FROM `pages` WHERE category='{category}';"
            cursor.execute(query_del)
            query = f'INSERT INTO pages VALUES {field}'
            cursor.execute(query)
            connection.commit()
            cursor.close()
            flash(
                f"Modify '{category}' on '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully." 'success')

    return redirect('/dashboard')


# **************************************** Page Modification *******************************************************
@app.route('/page_modification', methods=['GET', 'POST'])
def page_modification():
    if request.method == 'POST':
        # Get form data
        table_name = 'pages'
        category = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')

        title = request.form['title']
        description = request.form['description']
        keywords = request.form['keywords']
        otherMeta = request.form['other-meta']
        mainBlock = request.form['main-block']
        question1 = request.form['question1']
        answer1 = request.form['answer1']
        question2 = request.form['question2']
        answer2 = request.form['answer2']
        question3 = request.form['question3']
        answer3 = request.form['answer3']
        question4 = request.form['question4']
        answer4 = request.form['answer4']
        question5 = request.form['question5']
        answer5 = request.form['answer5']

        field = (
            category, title, description, keywords, otherMeta, mainBlock, question1, answer1, question2, answer2,
            question3, answer3, question4, answer4,
            question5,
            answer5)

        connection = con.connect(**db_config)
        cursor = connection.cursor()

        select_query = f"SELECT * FROM pages WHERE category = '{category}';"
        cursor.execute(select_query)
        category_SEL = cursor.fetchone()

        if category_SEL is None:
            query = f'INSERT INTO pages VALUES {field} '
            cursor.execute(query)
            connection.commit()
            cursor.close()
            flash(
                f"Insert on '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully.",
                'success')

        else:
            # Update data in the table
            query_del = f"DELETE FROM `pages` WHERE category='{category}';"
            cursor.execute(query_del)
            query = f'INSERT INTO pages VALUES {field}'
            cursor.execute(query)
            connection.commit()
            cursor.close()
            flash(
                f"Modify '{category}' on '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully." 'success')

    return redirect('/dashboard')


# ****************************************** Delete Page *************************************************************
@app.route('/delete_page', methods=['POST'])
def delete_page():
    category = request.form['category']
    try:
        # Delete the row from the table
        connection = con.connect(**db_config)
        cursor = connection.cursor()
        delete_query = f"DELETE FROM pages WHERE category = '{category}'"
        cursor.execute(delete_query)
        connection.commit()
        cursor.close()
        flash(f"Successfully delete page for category '{category}'.", 'success')
    except:
        flash(f"Failed to delete page for category '{category}'.", 'error')
    return redirect('/dashboard')


# ***************************************** Brand name data ********************************************************#

def create_table(table_name):
    cnx = con.connect(**db_config_category)
    cursor = cnx.cursor()

    # Check if the table already exists
    cursor.execute(f"SHOW TABLES LIKE '{table_name}'")
    table_exists = cursor.fetchone()

    # If the table doesn't exist, create it
    if not table_exists:
        create_table_query = f"""
        CREATE TABLE {table_name} (
            Brand_Name VARCHAR(50),
            Description VARCHAR(300),
            Tagline VARCHAR(50),
            Domain_availability VARCHAR(50),
            Trademark_availability VARCHAR(50)
        )
        """
        cursor.execute(create_table_query)
        cnx.commit()
        return True

    cursor.close()
    cnx.close()
    return False


def table_list():
    cnx = con.connect(**db_config_category)
    cursor = cnx.cursor()

    # Check if the table already exists
    cursor.execute(f"SHOW TABLES;")
    table_exist = cursor.fetchall()
    cursor.close()
    cnx.close()
    table_list_all = [j.capitalize().replace('and', '&').replace('_', ' ') for i in table_exist for j in i]

    return table_list_all


def insert_data(table_name, Brand_Name, description, tagline, domainAvailability, trademarkAvailability):
    cnx = con.connect(**db_config_category)
    cursor = cnx.cursor()

    # Insert data into the table
    insert_data_query = f"""
    INSERT INTO {table_name} (Brand_Name, Description, tagline, Domain_availability, Trademark_availability)
    VALUES (%s, %s, %s, %s, %s)
    """
    data_values = (Brand_Name, description, tagline, domainAvailability, trademarkAvailability)
    cursor.execute(insert_data_query, data_values)
    cnx.commit()

    cursor.close()
    cnx.close()


#
# def insert_page_data(table_name, field,category):
#     print(f'Inserting start on table {table_name}')
#     mydb = connection_db()
#
#     query = f"INSERT INTO pages VALUES {field} where category= {category}"
#     cur = mydb.cursor()
#     cur.execute(query)
#     mydb.commit()
#     print(f"Insertion done on table uses ")


@app.route('/User_Brand_Name', methods=['GET', 'POST'])
def Add_Brand_Name():
    if request.method == 'POST':
        # Get form data
        table_name = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')
        Brand_Name = request.form['brandName'].capitalize()
        description = request.form['description'].capitalize()
        tagline = request.form['tagline'].capitalize()
        domainAvailability = request.form['domainAvailability'].lower()
        trademarkAvailability = request.form['trademarkAvailability'].lower()

        try:
            # Insert data into the table
            insert_data(table_name, Brand_Name, description, tagline, domainAvailability,
                        trademarkAvailability)

            flash(
                f"Data inserted into table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully.",
                'success')
        except:
            flash(f"'{table_name.capitalize().replace('and', '&').replace('_', ' ')}' not present", 'error')

        return redirect('/data_entry_brand_name_dashboard')

    return redirect('/data_entry_brand_name_dashboard')


# ______________________super admin brand name___________________________
@app.route('/User_Brand_Name_super', methods=['GET', 'POST'])
def Add_Brand_Name_super():
    if request.method == 'POST':
        # Get form data
        table_name = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')
        Brand_Name = request.form['brandName'].capitalize()
        description = request.form['description'].capitalize()
        tagline = request.form['tagline'].capitalize()
        domainAvailability = request.form['domainAvailability'].lower()
        trademarkAvailability = request.form['trademarkAvailability'].lower()

        try:
            # Insert data into the table
            insert_data(table_name, Brand_Name, description, tagline, domainAvailability,
                        trademarkAvailability)

            flash(
                f"Data inserted into table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully.",
                'success')
        except:
            flash(f"'{table_name.capitalize().replace('and', '&').replace('_', ' ')}' not present", 'error')

        return redirect('/dashboard')

    return redirect('/dashboard')


# add brand category
@app.route('/Manager_Brand_Name', methods=['GET', 'POST'])
def Manager_Brand_Name1():
    if request.method == 'POST':
        # Get form data
        table_name = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')

        # Create table if it doesn't exist
        table_created = create_table(table_name)

        if table_created:
            flash(f"Table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' created successfully",
                  'success')
        else:
            flash(f"Table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' already Exit", 'error')

        return redirect('')

    return redirect('/manager_brand_name_dashboard')


# ***************************************** Brand name data ********************************************************#


# *****************************************  Manager Edit_brand_name route ********************************************************#
@app.route('/Manager_Edit_Brand_Name', methods=['GET', 'POST'])
def Edit_Brand_Name():
    if request.method == 'POST':
        # Get form data
        table_name = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')
        brand_name = request.form['brandName'].capitalize()
        description = request.form['description'].capitalize()
        tagline = request.form['tagline'].capitalize()
        domain_availability = request.form['domainAvailability'].lower()
        trademark_availability = request.form['trademarkAvailability'].lower()

        # Check if brand name exists in the table
        connection = con.connect(**db_config_category)
        cursor = connection.cursor()
        select_query = f"SELECT * FROM {table_name} WHERE Brand_Name = '{brand_name}';"
        cursor.execute(select_query)
        brand = cursor.fetchone()

        if brand is None:
            flash(
                f"'{brand_name}' not found in table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}'",
                'error')
        else:
            # Update data in the table
            try:
                update_query = f"""UPDATE {table_name} SET 
                                    Description='{description}',
                                    Tagline='{tagline}',
                                    Domain_availability='{domain_availability}',
                                    Trademark_availability='{trademark_availability}'
                                    WHERE Brand_Name ='{brand_name}';"""
                cursor.execute(update_query)
                connection.commit()
                cursor.close()
                flash(
                    f"Edit '{brand_name}' on '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully.",
                    'success')
            except Exception as e:
                flash(
                    f"An error occurred while updating '{brand_name}' in table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}': {str(e)}",
                    'error')
        connection.close()

    return redirect('manager_brand_name_dashboard')


# ***********************************************  user page modification *********************************************************************

# @app.route('/page_modification', methods=['GET', 'POST'])
# def page_modification1():
#     if request.method == 'POST':
#         # Get form data
#         table_name = 'pages'
#         category = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')
#         print(category)
#         # print(category)
#         title1 = request.form['title1']
#         par1 = request.form['par1']
#         par2 = request.form['par2']
#
#         title2 = request.form['title2']
#         list1 = request.form['list1']
#
#         # lines = request.form['list1'].split('\n')
#         #
#         # # Process each line to create the Python list
#         # list1 = []
#         # for line in lines:
#         #     line = line.strip()  # Remove leading and trailing whitespaces
#         #     if line:
#         #         elements = line.split(' ')  # Split line by space
#         #         list1.append(elements[-1])  # Add the last element to the list
#
#         title3 = request.form['title3']
#         list2 = request.form['list2']
#         list3 = request.form['list3']
#
#         par3 = request.form['par3']
#         par4 = request.form['par4']
#         par5 = request.form['par5']
#
#         title4 = request.form['title4']
#         par6 = request.form['par6']
#
#         titleFAQ = request.form['titleFAQ']
#         ques1 = request.form['ques1']
#         ansPar1 = request.form['ansPar1']
#
#         ques2 = request.form['ques2']
#         ansPar2 = request.form['ansPar2']
#
#         ques3 = request.form['ques3']
#         ansPar3 = request.form['ansPar3']
#
#         ques4 = request.form['ques4']
#         ansPar4 = request.form['ansPar4']
#
#         ques5 = request.form['ques5']
#         ansPar5 = request.form['ansPar5']
#
#         field = (category, title1, par1, par2, title2, list1, title3, list2, list3, par3, par4, par5,
#                  title4,
#                  par6, titleFAQ, ques1, ansPar1, ques2, ansPar2, ques3, ansPar3, ques4, ansPar4, ques5,
#                  ansPar5)
#
#         connection = con.connect(**db_config)
#         cursor = connection.cursor()
#
#         select_query = f"SELECT * FROM pages WHERE category = '{category}';"
#         cursor.execute(select_query)
#         category_SEL = cursor.fetchone()
#
#         if category_SEL is None:
#             query = f'INSERT INTO pages VALUES {field} '
#             cursor.execute(query)
#             connection.commit()
#             cursor.close()
#             flash(
#                 f"Insert on '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully.",
#                 'success')
#
#         else:
#             # Update data in the table
#             query_del = f"DELETE FROM `pages` WHERE category='{category}';"
#             cursor.execute(query_del)
#             query = f'INSERT INTO pages VALUES {field}'
#             cursor.execute(query)
#             connection.commit()
#             cursor.close()
#             flash(
#                 f"Modify '{category}' on '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully." 'success')
#
#     return redirect('data_entry_page_modification_dashboard')
#

# +++++++++++++++++++++page modification dashboard++++++++++++
# @app.route('/page_modification', methods=['GET', 'POST'])
# def page_modification_dasboard():
#     if request.method == 'POST':
#         # Get form data
#         table_name = 'pages'
#         category = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')
#         print(category)
#         # print(category)
#         title1 = request.form['title1']
#         par1 = request.form['par1']
#         par2 = request.form['par2']
#
#         title2 = request.form['title2']
#         list1 = request.form['list1']
#
#         # lines = request.form['list1'].split('\n')
#         #
#         # # Process each line to create the Python list
#         # list1 = []
#         # for line in lines:
#         #     line = line.strip()  # Remove leading and trailing whitespaces
#         #     if line:
#         #         elements = line.split(' ')  # Split line by space
#         #         list1.append(elements[-1])  # Add the last element to the list
#
#         title3 = request.form['title3']
#         list2 = request.form['list2']
#         list3 = request.form['list3']
#
#         par3 = request.form['par3']
#         par4 = request.form['par4']
#         par5 = request.form['par5']
#
#         title4 = request.form['title4']
#         par6 = request.form['par6']
#
#         titleFAQ = request.form['titleFAQ']
#         ques1 = request.form['ques1']
#         ansPar1 = request.form['ansPar1']
#
#         ques2 = request.form['ques2']
#         ansPar2 = request.form['ansPar2']
#
#         ques3 = request.form['ques3']
#         ansPar3 = request.form['ansPar3']
#
#         ques4 = request.form['ques4']
#         ansPar4 = request.form['ansPar4']
#
#         ques5 = request.form['ques5']
#         ansPar5 = request.form['ansPar5']
#
#         field = (category, title1, par1, par2, title2, list1, title3, list2, list3, par3, par4, par5,
#                  title4,
#                  par6, titleFAQ, ques1, ansPar1, ques2, ansPar2, ques3, ansPar3, ques4, ansPar4, ques5,
#                  ansPar5)
#
#         connection = con.connect(**db_config)
#         cursor = connection.cursor()
#
#         select_query = f"SELECT * FROM pages WHERE category = '{category}';"
#         cursor.execute(select_query)
#         category_SEL = cursor.fetchone()
#
#         if category_SEL is None:
#             query = f'INSERT INTO pages VALUES {field} '
#             cursor.execute(query)
#             connection.commit()
#             cursor.close()
#             flash(
#                 f"Insert on '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully.",
#                 'success')
#
#         else:
#             # Update data in the table
#             query_del = f"DELETE FROM `pages` WHERE category='{category}';"
#             cursor.execute(query_del)
#             query = f'INSERT INTO pages VALUES {field}'
#             cursor.execute(query)
#             connection.commit()
#             cursor.close()
#             flash(
#                 f"Modify '{category}' on '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully." 'success')
#
#     return redirect("/dashboard")


# ****************************************** all route******************************************************************


@app.route('/brand_name_data_entry_dashboard')
def brand_name_data_entry_dashboard():
    category_list = table_list()
    return render_template('brand_name_data_entry_dashboard.html', category_list=category_list)


@app.route('/brand_name_manager_dashboard')
def brand_name_manager_dashboard():
    category_list = table_list()
    return render_template('brand_name_manager_dashboard.html', category_list=category_list)


@app.route('/page_modification_page_editor_dashboard')
def page_modification_page_editor_dashboard():
    category_list = table_list()
    return render_template('page_modification_page_editor_dashboard.html', category_list=category_list)


@app.route('/page_modification_page_manager_dashboard')
def page_modification_page_manager_dashboard():
    category_list = table_list()
    return render_template('page_modification_page_manager_dashboard.html', category_list=category_list)


# ******************************************************************************************

if __name__ == "__main__":
    print(allCategorypage())
    app.run(debug=True, host='0.0.0.0')
