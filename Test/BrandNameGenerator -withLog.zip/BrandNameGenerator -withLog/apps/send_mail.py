import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from email.mime.base import MIMEBase
from email import encoders
from core import logger

logger = logger.create_logger("receive_mail")


def send_email(receiver_email, subject, body):
    # sender_email = "info@unboxfame.us"
    # password = 'R13-@-y}^NF,'
    # sender_email = 'pooja.das@unboxfame.com'
    # password = 'Poojadas@123'

    sender_email = "pooja.das@unboxfame.com"
    sender_name = "UnboxFame"
    password = 'Poojadas@123'

    message = MIMEMultipart()
    message["From"] = f"{sender_name} <{sender_email}>"
    # message["From"] = send_email
    message["To"] = receiver_email
    message["Subject"] = subject

    message.attach(MIMEText(body, "html"))

    # Attach the logo image to the email
    with open('apps/img/logo.png', "rb") as image_file:
        image_data = image_file.read()
        image = MIMEImage(image_data, name="logo.png")
        image.add_header("Content-ID", "<logo_image>")
        message.attach(image)

    # Attach the facebook image to the email
    with open('apps/img/facebook.png', "rb") as image_file:
        image_data = image_file.read()
        image = MIMEImage(image_data, name="facebook.png")
        image.add_header("Content-ID", "<facebook_logo>")
        message.attach(image)

    # Attach the youtube image to the email
    with open('apps/img/youtube.png', "rb") as image_file:
        image_data = image_file.read()
        image = MIMEImage(image_data, name="youtube.png")
        image.add_header("Content-ID", "<youtube_logo>")
        message.attach(image)

        # Attach the linkedIn image to the email
    with open('apps/img/linkedIn.png', "rb") as image_file:
        image_data = image_file.read()
        image = MIMEImage(image_data, name="linkedIn.png")
        image.add_header("Content-ID", "<linkedIn_logo>")
        message.attach(image)

        # Attach the linkedIn image to the email
    with open('apps/img/instragram.png', "rb") as image_file:
        image_data = image_file.read()
        image = MIMEImage(image_data, name="instragram.png")
        image.add_header("Content-ID", "<instragram_logo>")
        message.attach(image)

        # Attach the pinterest image to the email
    with open('apps/img/pinterest.png', "rb") as image_file:
        image_data = image_file.read()
        image = MIMEImage(image_data, name="pinterest.png")
        image.add_header("Content-ID", "<pinterest_logo>")
        message.attach(image)

        # Attach the twitter image to the email
    with open('apps/img/twitter.png', "rb") as image_file:
        image_data = image_file.read()
        image = MIMEImage(image_data, name="twitter.png")
        image.add_header("Content-ID", "<twitter_logo>")
        message.attach(image)

    try:
        server = smtplib.SMTP_SSL("mail.unboxfame.us", 465)  # Set SMTP server and port
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, message.as_string())
        logger.info("Email sent successfully!")
    except Exception as e:
        logger.exception(e)
        logger.info("Failed to send email.")
    finally:
        server.quit()

# receiver_email = "pooja.das@unboxfame.com"
# subject = 'Thank you for filling out the form'
# message = f"""Thank You pooja
#                   Thank you for going to the customized brand name for your business. We can assure you that you are in the right direction. We hope you will be satisfied with the names given by our brand naming experts."""
#
# send_email(receiver_email, subject, message)
