# app.py
from flask import Flask, render_template, request
import razorpay

app = Flask(__name__)

# Razorpay API credentials
razorpay_key_id = 'YOUR_RAZORPAY_KEY_ID'
razorpay_key_secret = 'YOUR_RAZORPAY_KEY_SECRET'

# List of brand names
brand_names = ["Apple", "Google", "Microsoft", "Amazon", "Facebook"]


@app.route('/')
def index():
    return render_template('index.html', brand_names=brand_names)


@app.route('/pay', methods=['POST'])
def pay():
    selected_name = request.form['brand_name']
    client = razorpay.Client(auth=(razorpay_key_id, razorpay_key_secret))

    # Create a Razorpay order
    order_amount = 1000  # Amount in paisa (example: ₹10)
    order_currency = 'INR'
    order_receipt = 'order_receipt'  # Generate a unique order receipt
    notes = {'selected_name': selected_name}  # Additional notes (optional)
    order = client.order.create(
        {'amount': order_amount, 'currency': order_currency, 'receipt': order_receipt, 'notes': notes})

    # Pass the order details to the payment page
    return render_template('payment_success.html', order=order, selected_name=selected_name)


@app.route('/payment_success', methods=['POST'])
def payment_success():
    # Verify the Razorpay payment
    razorpay_payment_id = request.form['razorpay_payment_id']
    razorpay_order_id = request.form['razorpay_order_id']
    razorpay_signature = request.form['razorpay_signature']
    client = razorpay.Client(auth=(razorpay_key_id, razorpay_key_secret))
    params_dict = {
        'razorpay_payment_id': razorpay_payment_id,
        'razorpay_order_id': razorpay_order_id,
        'razorpay_signature': razorpay_signature
    }
    try:
        client.utility.verify_payment_signature(params_dict)
        selected_name = request.form['selected_name']
        # Unhide the brand name (implement your logic here)
        return render_template('payment_success.html', selected_name=selected_name)
    except razorpay.errors.SignatureVerificationError:
        return "Payment verification failed."


if __name__ == '__main__':
    app.run(debug=True)
