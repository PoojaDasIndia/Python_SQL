from datetime import datetime
import os
import logging


def create_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    file_handler = logging.FileHandler('app_log.log', mode='a')
    formatter = logging.Formatter('%(asctime)s-%(levelname)s-%(message)s', datefmt='%d-%B-%y|%A| %H:%M:%S %p')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger
