import random
from flask import Flask, render_template, request, redirect, url_for
import mysql.connector as con
import whois

db_config = {
    'host': 'localhost',
    'database': 'Unboxfamedata',
    'user': 'root',
    'password': ''
}


def get_raw_whois(domain):
    w = whois.whois(domain)
    return w.text


def insert_domain(domain):
    connection = con.connect(**db_config)
    cursor = connection.cursor()
    select_query = f"INSERT INTO `domain_search`(`domain`) VALUES ('{domain}')"
    cursor.execute(select_query)
    connection.commit()
    cursor.close()


# Object for Flask
app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/search', methods=['POST', 'GET'])
def generate():
    if request.method == 'POST':
        result = request.form.to_dict()
        # search  name
        domain = result['keywords']
        if domain == "":
            error = "Kindly insert Domain Name"
            raw_whois = None
        else:
            insert_domain(domain)
            error = None
            raw_whois = get_raw_whois(domain)
        # return field
        return render_template('index.html', raw_whois=raw_whois, error=error)


if __name__ == "__main__":
    print(get_raw_whois("unboxfame.com"))
    app.run(debug=True, host='localhost')
