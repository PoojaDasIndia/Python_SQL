from typing import List, Any

from flask import Flask, render_template, request, url_for, redirect
import pandas as pd
import random
import itertools

All = pd.read_excel("Data/Industry.xlsx", sheet_name='All')
Travel = pd.read_excel("Data/Industry.xlsx", sheet_name='Travel')
Real_Estate = pd.read_excel("Data/Industry.xlsx", sheet_name='Real Estate')
Education = pd.read_excel("Data/Industry.xlsx", sheet_name='Education')
Fashion = pd.read_excel("Data/Industry.xlsx", sheet_name='Fashion')
Agriculture = pd.read_excel("Data/Industry.xlsx", sheet_name='Agriculture')

# Object for Flask
app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/generate', methods=['POST'])
def generate():
    if request.method == 'POST':
        input_text = request.form['bname']
        industry = request.form['Industry']
        if industry == "All":
            pre_res = [input_text + ' ' + sub.capitalize() for sub in All['Name']]
            suf_res = [sub.capitalize() + ' ' + input_text for sub in All['Name']]
        elif industry == "Travel":
            pre_res = [input_text + ' ' + sub.capitalize() for sub in Travel['Name']]
            suf_res = [sub.capitalize() + ' ' + input_text for sub in Travel['Name']]
        elif industry == "Real_Estate":
            pre_res = [input_text + ' ' + sub.capitalize() for sub in Real_Estate['Name']]
            suf_res = [sub.capitalize() + ' ' + input_text for sub in Real_Estate['Name']]
        elif industry == "Education":
            pre_res = [input_text + ' ' + sub.capitalize() for sub in Education['Name']]
            suf_res = [sub.capitalize() + ' ' + input_text for sub in Education['Name']]
        elif industry == "Fashion":
            pre_res = [input_text + ' ' + sub.capitalize() for sub in Fashion['Name']]
            suf_res = [sub.capitalize() + ' ' + input_text for sub in Fashion['Name']]
        elif industry == "Agriculture":
            pre_res = [input_text + ' ' + sub.capitalize() for sub in Agriculture['Name']]
            suf_res = [sub.capitalize() + ' ' + input_text for sub in Agriculture['Name']]


    main = pre_res + suf_res
    random.shuffle(main)

    final = main[0:200]

    # 3. Display

    return render_template('index.html', data = final)




if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0')
