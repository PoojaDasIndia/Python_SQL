import whois

from core import logger

logger = logger.create_logger("domain_check")


def check_domain_availability(domain_name):
    try:
        logger.info("start searching domain")
        w = whois.whois(domain_name)
        logger.info("searching done")
        if w.status is None:
            return "Available"
        else:
            return "Already taken"
    except Exception as er:
        logger.exception(f"getting error while domain search {domain_name}")
        return "Available"



# Call the function to check the availability of the domain name
# domain_name = "unboxfame.com"
# check_domain_availability(domain_name)
