import openai
import random


# Set up OpenAI API credentials
openai.api_key = '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'


# Define a function to generate brand name suggestions
def generate_brand_name(seed_text):
    # Generate 10 brand name suggestions using GPT-3
    response = openai.Completion.create(
        engine="text-davinci-002",
        prompt=f"Generate 100 brand names related to '{seed_text}'",
        temperature=0.5,
        max_tokens=50,
        n=100,
        stop=None,
    )

    # Extract the generated names from the OpenAI API response
    generated_names = []
    for suggestion in response.choices:
        text = suggestion.text.strip()
        if text:
            generated_names.append(text)

    # Return a random name from the list of generated names
    if generated_names:
        return random.choice(generated_names)
    else:
        return None


# Example usage
brand_name = generate_brand_name("Cello")
print(brand_name)
