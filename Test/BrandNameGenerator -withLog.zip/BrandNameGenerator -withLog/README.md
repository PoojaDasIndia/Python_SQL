### BrandNameGenerator
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_email(sender_email, sender_password, receiver_email, subject, message):
    # Set up the SMTP server
    smtp_server = 'your_smtp_server'
    smtp_port = 587  # Change the port if needed

    try:
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(sender_email, sender_password)

        # Create the email message
        email = MIMEMultipart()
        email['From'] = sender_email
        email['To'] = receiver_email
        email['Subject'] = subject
        email.attach(MIMEText(message, 'plain'))

        # Send the email
        server.sendmail(sender_email, receiver_email, email.as_string())
        print("Email sent successfully!")
    except Exception as e:
        print("Error sending email:", str(e))
    finally:
        server.quit()

# Example usage
sender_email = 'your_email@example.com'
sender_password = 'your_password'
receiver_email = 'user@example.com'
subject = 'Thank you for filling out the form'
message = 'Dear user, thank you for filling out the form. We appreciate your participation.'

send_email(sender_email, sender_password, receiver_email, subject, message)

name.com reseller api

https://www.name.com/resellersolutions
