import random

# Define the paragraph idea and desired prefix/suffix
idea = "I am Pooja Das. I want to start a boutique business."
prefix_suffix = "Pooja"

# Generate a list of candidate brand names
brand_names = []
for i in range(20):
    # Choose a random word from the idea
    words = idea.split()
    word = random.choice(words)

    # Construct the brand name with the chosen word as prefix or suffix
    if random.choice([True, False]):
        brand_name = prefix_suffix + word.capitalize()
    else:
        brand_name = word.capitalize() + prefix_suffix

    # Add the brand name to the list
    brand_names.append(brand_name)

# Print the suggested brand names
print("Suggested brand names:")
for brand_name in brand_names:
    print(brand_name)

