import random

# List of keywords that could be used in the brand name
keywords = ['tech', 'innovation', 'creative', 'solutions', 'global', 'future', 'digital', 'smart']


# Function to generate a brand name suggestion
def suggest_brand_name():
    # Choose 2 or 3 keywords at random
    num_keywords = random.randint(2, 3)
    chosen_keywords = random.sample(keywords, num_keywords)

    # Capitalize each keyword and join them with a space
    brand_name = ' '.join(word.capitalize() for word in chosen_keywords)

    return brand_name


# Example usage
suggested_name = suggest_brand_name()
print(suggested_name)
