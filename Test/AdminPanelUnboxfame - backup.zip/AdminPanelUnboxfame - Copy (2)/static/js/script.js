//__________________________ Edit brand name toggle___________________________
function toggleHome(){
  var homeForm = document.getElementById("home-form");
  var allForm = document.getElementById("all-form");
  var editForm = document.getElementById("edit-form");
  var deleteForm = document.getElementById("delete-form");
  var addUserForm = document.getElementById("AddUser-form");
  var addBrandNameForm = document.getElementById("addBrandName-form");
  var addCategory = document.getElementById("addCategory-form");
  var editBrandNameForm = document.getElementById("editBrandName-form");
  var pageEditorForm = document.getElementById("pageEditor-form");
  var pageModifierForm = document.getElementById("pageModifier-form");
  var pageDeleteForm = document.getElementById("pageDelete-form");

  homeForm.style.display = "block";
  allForm.style.display = "none";
  editForm.style.display = "none";
  deleteForm.style.display = "none";
  addUserForm.style.display = "none";
  addBrandNameForm.style.display = "none";
  addCategory.style.display = "none";
  editBrandNameForm.style.display = "none";
  pageEditorForm.style.display = "none";
  pageModifierForm.style.display = "none";
  pageDeleteForm.style.display = "none";
  hideFlashMessages();
}

//________________________all user toggle______________________
function toggleAllUserForm() {
  var homeForm = document.getElementById("home-form");
  var allForm = document.getElementById("all-form");
  var editForm = document.getElementById("edit-form");
  var deleteForm = document.getElementById("delete-form");
  var addUserForm = document.getElementById("AddUser-form");
  var addBrandNameForm = document.getElementById("addBrandName-form");
  var addCategory = document.getElementById("addCategory-form");
  var editBrandNameForm = document.getElementById("editBrandName-form");
  var pageEditorForm = document.getElementById("pageEditor-form");
  var pageModifierForm = document.getElementById("pageModifier-form");
  var pageDeleteForm = document.getElementById("pageDelete-form");

  homeForm.style.display = "none";
  allForm.style.display = "block";
  editForm.style.display = "none";
  deleteForm.style.display = "none";
  addUserForm.style.display = "none";
  addBrandNameForm.style.display = "none";
  addCategory.style.display = "none";
  editBrandNameForm.style.display = "none";
  pageEditorForm.style.display = "none";
  pageModifierForm.style.display = "none";
  pageDeleteForm.style.display = "none";

  hideFlashMessages();
}


// ____________________  edit user_____________________________
function toggleEditForm(username) {
  var homeForm = document.getElementById("home-form");
  var allForm = document.getElementById("all-form");
  var editForm = document.getElementById("edit-form");
  var deleteForm = document.getElementById("delete-form");
  var addUserForm = document.getElementById("AddUser-form");
  var addBrandNameForm = document.getElementById("addBrandName-form");
  var addCategory = document.getElementById("addCategory-form");
  var editBrandNameForm = document.getElementById("editBrandName-form");
  var pageEditorForm = document.getElementById("pageEditor-form");
  var pageModifierForm = document.getElementById("pageModifier-form");
  var pageDeleteForm = document.getElementById("pageDelete-form");

  homeForm.style.display = "none";
  allForm.style.display = "none";
  editForm.style.display = "block";
  deleteForm.style.display = "none";
  addUserForm.style.display = "none";
  addBrandNameForm.style.display = "none";
  addCategory.style.display = "none";
  editBrandNameForm.style.display = "none";
  pageEditorForm.style.display = "none";
  pageModifierForm.style.display = "none";
  pageDeleteForm.style.display = "none";

  populateEditFormFields(username);

  hideFlashMessages();
}

function populateEditFormFields(username) {
  var editUsernameInput = document.getElementById("edit-username");
  var editFirstnameInput = document.getElementById("edit-firstname");
  var editLastnameInput = document.getElementById("edit-lastname");
  var editEmailInput = document.getElementById("edit-email");
  var editPasswordInput = document.getElementById("edit-password");
  var editUserTypeInput = document.getElementById("edit-user-type");
  var editRoleInput = document.getElementById("edit-role");

  var rows = document.querySelectorAll("#all-form table tr");
  for (var i = 1; i < rows.length; i++) {
    var cells = rows[i].getElementsByTagName("td");
    var recordUsername = cells[0].textContent;
    if (recordUsername === username) {
      editUsernameInput.value = recordUsername;
      editFirstnameInput.value = cells[1].textContent;
      editLastnameInput.value = cells[2].textContent;
      editEmailInput.value = cells[3].textContent;
      editPasswordInput.value = cells[4].textContent;
      editUserTypeInput.value = cells[5].textContent;
      editRoleInput.value = cells[6].textContent;
      break;
    }
  }
}

// ____________________password validation For edit__________________________________
function editvalidateForm() {
  var passwordInput = document.getElementById("edit-password");

  var password = passwordInput.value;

  if (password.length < 6) {
    alert("Password length must be at least 6 characters");
    return false;
  }

}

// ______________________________for delete  username___________________________

function toggleDeleteForm(username) {
  var homeForm = document.getElementById("home-form");
  var allForm = document.getElementById("all-form");
  var editForm = document.getElementById("edit-form");
  var deleteForm = document.getElementById("delete-form");
  var addUserForm = document.getElementById("AddUser-form");
  var addBrandNameForm = document.getElementById("addBrandName-form");
  var addCategory = document.getElementById("addCategory-form");
  var editBrandNameForm = document.getElementById("editBrandName-form");
  var pageEditorForm = document.getElementById("pageEditor-form");
  var pageModifierForm = document.getElementById("pageModifier-form");
  var pageDeleteForm = document.getElementById("pageDelete-form");

  homeForm.style.display = "none";
  allForm.style.display = "none";
  editForm.style.display = "none";
  deleteForm.style.display = "block";
  addUserForm.style.display = "none";
  addBrandNameForm.style.display = "none";
  addCategory.style.display = "none";
  editBrandNameForm.style.display = "none";
  pageEditorForm.style.display = "none";
  pageModifierForm.style.display = "none";
  pageDeleteForm.style.display = "none";

  populateDeleteFormUsername(username)
  hideFlashMessages();
}

function populateDeleteFormUsername(username) {
  var deleteUsernameInput = document.getElementById("delete-username");
  deleteUsernameInput.value = username;
}

//_________________________Delete confirmation_________________________
function confirmDelete() {
  var deleteUsernameInput = document.getElementById("delete-username");
  var deleteUsername = deleteUsernameInput.value;

  if (!confirm("Are you sure you want to delete user " + deleteUsername + "?")) {
    return false;
  }
}


// _______________________Add user form  toggle_________________________
function toggleAddUserForm() {
  var homeForm = document.getElementById("home-form");
  var allForm = document.getElementById("all-form");
  var editForm = document.getElementById("edit-form");
  var deleteForm = document.getElementById("delete-form");
  var addUserForm = document.getElementById("AddUser-form");
  var addBrandNameForm = document.getElementById("addBrandName-form");
  var addCategory = document.getElementById("addCategory-form");
  var editBrandNameForm = document.getElementById("editBrandName-form");
  var pageEditorForm = document.getElementById("pageEditor-form");
  var pageModifierForm = document.getElementById("pageModifier-form");
  var pageDeleteForm = document.getElementById("pageDelete-form");

  homeForm.style.display = "none";
  allForm.style.display = "none";
  editForm.style.display = "none";
  deleteForm.style.display = "none";
  addUserForm.style.display = "block";
  addBrandNameForm.style.display = "none";
  addCategory.style.display = "none";
  editBrandNameForm.style.display = "none";
  pageEditorForm.style.display = "none";
  pageModifierForm.style.display = "none";
  pageDeleteForm.style.display = "none";

  hideFlashMessages();
}

//________________________ Role selection depend on user type______________________
function toggleRoleSelect() {
  var userTypeSelect = document.getElementById("user_type");
  var roleSelect = document.getElementById("role");

  if (userTypeSelect.value === "Brand_Name") {
    roleSelect.style.display = "block";
    roleSelect.innerHTML = `
      <option value="">Select Role</option>
      <option value="Data_Entry">Data Entry</option>
      <option value="Manager">Manager</option>
    `;
  } else if (userTypeSelect.value === "Page_modification") {
    roleSelect.style.display = "block";
    roleSelect.innerHTML = `
      <option value="">Select Role</option>
      <option value="Page_Editor">Page Editor</option>
      <option value="Page_Manager">Page Manager</option>
    `;
  } else {
    roleSelect.style.display = "none";
  }
}

//______________________ password validation For user ____________________
function validateForm() {
  var passwordInput = document.getElementById("password");
  var confirmPasswordInput = document.getElementById("confirm-password");

  var password = passwordInput.value;
  var confirmPassword = confirmPasswordInput.value;

  if (password.length < 6) {
    alert("Password length must be at least 6 characters");
    return false;
  }

  if (password !== confirmPassword) {
    alert("Passwords do not match");
    return false;
  }
}


//__________________________ Add brand name toggle___________________________
function toggleAddBrandNameForm() {
  var homeForm = document.getElementById("home-form");
  var allForm = document.getElementById("all-form");
  var editForm = document.getElementById("edit-form");
  var deleteForm = document.getElementById("delete-form");
  var addUserForm = document.getElementById("AddUser-form");
  var addBrandNameForm = document.getElementById("addBrandName-form");
  var addCategory = document.getElementById("addCategory-form");
  var editBrandNameForm = document.getElementById("editBrandName-form");
  var pageEditorForm = document.getElementById("pageEditor-form");
  var pageModifierForm = document.getElementById("pageModifier-form");
  var pageDeleteForm = document.getElementById("pageDelete-form");

  homeForm.style.display = "none";
  allForm.style.display = "none";
  editForm.style.display = "none";
  deleteForm.style.display = "none";
  addUserForm.style.display = "none";
  addBrandNameForm.style.display = "block";
  addCategory.style.display = "none";
  editBrandNameForm.style.display = "none";
  pageEditorForm.style.display = "none";
  pageModifierForm.style.display = "none";
  pageDeleteForm.style.display = "none";

  hideFlashMessages();
}



// ___________________________________  Add Category ____________________________________
function toggleAddCategoryForm() {
  var homeForm = document.getElementById("home-form");
  var allForm = document.getElementById("all-form");
  var editForm = document.getElementById("edit-form");
  var deleteForm = document.getElementById("delete-form");
  var addUserForm = document.getElementById("AddUser-form");
  var addBrandNameForm = document.getElementById("addBrandName-form");
  var addCategory = document.getElementById("addCategory-form");
  var editBrandNameForm = document.getElementById("editBrandName-form");
  var pageEditorForm = document.getElementById("pageEditor-form");
  var pageModifierForm = document.getElementById("pageModifier-form");
  var pageDeleteForm = document.getElementById("pageDelete-form");

  homeForm.style.display = "none";
  allForm.style.display = "none";
  editForm.style.display = "none";
  deleteForm.style.display = "none";
  addUserForm.style.display = "none";
  addBrandNameForm.style.display = "none";
  addCategory.style.display = "block";
  editBrandNameForm.style.display = "none";
  pageEditorForm.style.display = "none";
  pageModifierForm.style.display = "none";
  pageDeleteForm.style.display = "none";
  hideFlashMessages();
}


//__________________________ Edit brand name toggle___________________________
function toggleEditBrandNameForm() {
  var homeForm = document.getElementById("home-form");
  var allForm = document.getElementById("all-form");
  var editForm = document.getElementById("edit-form");
  var deleteForm = document.getElementById("delete-form");
  var addUserForm = document.getElementById("AddUser-form");
  var addBrandNameForm = document.getElementById("addBrandName-form");
  var addCategory = document.getElementById("addCategory-form");
  var editBrandNameForm = document.getElementById("editBrandName-form");
  var pageEditorForm = document.getElementById("pageEditor-form");
  var pageModifierForm = document.getElementById("pageModifier-form");
  var pageDeleteForm = document.getElementById("pageDelete-form");

  homeForm.style.display = "none";
  allForm.style.display = "none";
  editForm.style.display = "none";
  deleteForm.style.display = "none";
  addUserForm.style.display = "none";
  addBrandNameForm.style.display = "none";
  addCategory.style.display = "none";
  editBrandNameForm.style.display = "block";
  pageEditorForm.style.display = "none";
  pageModifierForm.style.display = "none";
  pageDeleteForm.style.display = "none";
  hideFlashMessages();
}



//__________________________ Page Editor _______________________________________________
function togglePageEditorForm(){
  var homeForm = document.getElementById("home-form");
  var allForm = document.getElementById("all-form");
  var editForm = document.getElementById("edit-form");
  var deleteForm = document.getElementById("delete-form");
  var addUserForm = document.getElementById("AddUser-form");
  var addBrandNameForm = document.getElementById("addBrandName-form");
  var addCategory = document.getElementById("addCategory-form");
  var editBrandNameForm = document.getElementById("editBrandName-form");
  var pageEditorForm = document.getElementById("pageEditor-form");
  var pageModifierForm = document.getElementById("pageModifier-form");
  var pageDeleteForm = document.getElementById("pageDelete-form");

  homeForm.style.display = "none";
  allForm.style.display = "none";
  editForm.style.display = "none";
  deleteForm.style.display = "none";
  addUserForm.style.display = "none";
  addBrandNameForm.style.display = "none";
  addCategory.style.display = "none";
  editBrandNameForm.style.display = "none";
  pageEditorForm.style.display = "block";
  pageModifierForm.style.display = "none";
  pageDeleteForm.style.display = "none";
  hideFlashMessages();
}



//---------------------Page Modifier ------------------------

function togglePageModifierForm(){
  var homeForm = document.getElementById("home-form");
  var allForm = document.getElementById("all-form");
  var editForm = document.getElementById("edit-form");
  var deleteForm = document.getElementById("delete-form");
  var addUserForm = document.getElementById("AddUser-form");
  var addBrandNameForm = document.getElementById("addBrandName-form");
  var addCategory = document.getElementById("addCategory-form");
  var editBrandNameForm = document.getElementById("editBrandName-form");
  var pageEditorForm = document.getElementById("pageEditor-form");
  var pageModifierForm = document.getElementById("pageModifier-form");
  var pageDeleteForm = document.getElementById("pageDelete-form");

  homeForm.style.display = "none";
  allForm.style.display = "none";
  editForm.style.display = "none";
  deleteForm.style.display = "none";
  addUserForm.style.display = "none";
  addBrandNameForm.style.display = "none";
  addCategory.style.display = "none";
  editBrandNameForm.style.display = "none";
  pageEditorForm.style.display = "none";
  pageModifierForm.style.display = "block";
  pageDeleteForm.style.display = "none";

  hideFlashMessages();
}




//---------------------Page Delete ------------------------

function togglePageDeleteForm(){
  var homeForm = document.getElementById("home-form");
  var allForm = document.getElementById("all-form");
  var editForm = document.getElementById("edit-form");
  var deleteForm = document.getElementById("delete-form");
  var addUserForm = document.getElementById("AddUser-form");
  var addBrandNameForm = document.getElementById("addBrandName-form");
  var addCategory = document.getElementById("addCategory-form");
  var editBrandNameForm = document.getElementById("editBrandName-form");
  var pageEditorForm = document.getElementById("pageEditor-form");
  var pageModifierForm = document.getElementById("pageModifier-form");
  var pageDeleteForm = document.getElementById("pageDelete-form");

  homeForm.style.display = "none";
  allForm.style.display = "none";
  editForm.style.display = "none";
  deleteForm.style.display = "none";
  addUserForm.style.display = "none";
  addBrandNameForm.style.display = "none";
  addCategory.style.display = "none";
  editBrandNameForm.style.display = "none";
  pageEditorForm.style.display = "none";
  pageModifierForm.style.display = "none";
  pageDeleteForm.style.display = "block";

  hideFlashMessages();
}

//_________________________Page Delete confirmation_________________________
function confirmDeletePage() {
    var deletePageInput = document.getElementById("searchInput_delete");
    var deletePage = deletePageInput.value;

    if (!confirm("Are you sure you want to delete page " + deletePage + "?")) {
      return false;
    }
  }





//_____________ Hide flash messages______________
function hideFlashMessages() {
  var flashMessages = document.getElementsByClassName("flash-messages")[0];
  flashMessages.style.display = "none";
}



// ____________________ logout _____________________________
function logout() {
      // Perform any necessary logout logic here
      window.location.href = "/"; // Redirect to the home page
    }



// ____________________ go back _____________________________
 function goBack() {
      window.history.back();
    }

function toggleEditCategoryPage(record){
  var homeForm = document.getElementById("home-form");
  var allForm = document.getElementById("all-form");
  var editForm = document.getElementById("edit-form");
  var deleteForm = document.getElementById("delete-form");
  var addUserForm = document.getElementById("AddUser-form");
  var addBrandNameForm = document.getElementById("addBrandName-form");
  var addCategory = document.getElementById("addCategory-form");
  var editBrandNameForm = document.getElementById("editBrandName-form");
  var pageEditorForm = document.getElementById("pageEditor-form");
  var pageModifierForm = document.getElementById("pageModifier-form");
  var pageDeleteForm = document.getElementById("pageDelete-form");
  var editPageForm = document.getElementById("editPage-form");

  homeForm.style.display = "none";
  allForm.style.display = "none";
  editForm.style.display = "none";
  deleteForm.style.display = "none";
  addUserForm.style.display = "none";
  addBrandNameForm.style.display = "none";
  addCategory.style.display = "none";
  editBrandNameForm.style.display = "none";
  pageEditorForm.style.display = "none";
  pageModifierForm.style.display = "none";
  pageDeleteForm.style.display = "none";
  editPageForm.style.display = "block";

  populateEditPageFields(record);

  hideFlashMessages();
}

function populateEditPageFields(record) {
  var editUsernameInput = document.getElementById("edit-category");
  var editFirstnameInput = document.getElementById("edit-title");
  var editLastnameInput = document.getElementById("edit-description");
  var editEmailInput = document.getElementById("edit-Keywords");
  var editPasswordInput = document.getElementById("edit-Other_Meta");
  var editUserTypeInput = document.getElementById("edit-Main_Block");
  var editRoleInput = document.getElementById("edit-Question1");
  var editAnswerInput = document.getElementById("edit-Answer1");

  var rows = document.querySelectorAll("#pageModifier-form table tr");
  for (var i = 1; i < rows.length; i++) {
    var cells = rows[i].getElementsByTagName("td");
    var recordUsername = cells[0].textContent;
    if (recordUsername === record) {
      editUsernameInput.value = recordUsername;
      editFirstnameInput.value = cells[1].textContent;
      editLastnameInput.value = cells[2].textContent;
      editEmailInput.value = cells[3].textContent;
      editPasswordInput.value = cells[4].textContent;
      editUserTypeInput.value = cells[5].textContent;
      editRoleInput.value = cells[6].textContent;
      editAnswerInput.value = cells[7].textContent;
      break;
    }
  }
}
