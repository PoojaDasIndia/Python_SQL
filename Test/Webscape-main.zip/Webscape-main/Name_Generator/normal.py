import random

# lists of adjectives and nouns to generate brand names
adjectives = ['cool', 'modern', 'bold', 'sleek', 'elegant', 'vibrant', 'dynamic', 'innovative', 'fierce', 'fresh']
nouns = ['tech', 'labs', 'solutions', 'co', 'hub', 'network', 'venture', 'wave', 'works', 'cloud']

# function to generate a brand name
def suggest_brand_name():
    # randomly select an adjective and noun
    adj = random.choice(adjectives)
    noun = random.choice(nouns)
    # combine the two words to create a brand name
    brand_name = adj.capitalize() + noun.capitalize()
    return brand_name

# example usage
print(suggest_brand_name())  # output: CoolWorks
