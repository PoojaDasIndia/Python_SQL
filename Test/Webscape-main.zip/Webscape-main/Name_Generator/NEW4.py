import random

# Given paragraph idea
idea = "I am Pooja Das. I want to start a boutique business."

# List of candidate brand names
names = []

# Generate 20 brand names starting or ending with "Dodo"
for i in range(20):
    # Choose "Dodo" to be at the start or end of the name randomly
    if random.choice([True, False]):
        name = "Dodo" + idea.split()[2]  # Use the first name from the idea
    else:
        name = idea.split()[2] + "Dodo"

    # Add a random number between 100 and 999 to the end of the name
    name += str(random.randint(100, 999))

    # Add the name to the list
    names.append(name)

# Print the list of names
for name in names:
    print(name)
