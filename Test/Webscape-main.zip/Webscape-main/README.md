# Webscape
Office work
https://digital.abudhabichamber.ae/portal/#/commercial-directory

https://medium.com/python-pandemonium/6-things-to-develop-an-efficient-web-scraper-in-python-1dffa688793c
 
https://novanym.com/sitemap_products_1.xml?from=395646149&to=7941122228465

https://looka.com/business-name-generator/

https://www.w3schools.com/howto/howto_js_form_steps.asp

https://mouse-jiggler.en.softonic.com/

https://www.gujaratdirectory.com/companyinfo/metloy-blasttech-ahmedabad-36206.html


https://developer.domain.com.au/docs/latest/

