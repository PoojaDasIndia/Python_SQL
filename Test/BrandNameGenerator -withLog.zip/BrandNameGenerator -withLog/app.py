import random
from flask import Flask, render_template, request, redirect, url_for
from database import database_op
from apps import send_mail, receive_mail
from apps import domain_check
from core import logger
import mysql.connector as con

from mysql.connector import Error
from flask import Flask, render_template, request, redirect, flash, session
import mysql.connector as con
import secrets
from datetime import date

logger = logger.create_logger("app")

database_name = "UnboxfameData"
table_name_category = "category"
table_name_query = "query_file"
table_name_enquire = 'Enquire'
table_name_book = "Domain_Enquire"
password = ""

db_config = {
    'host': 'localhost',
    'database': 'Unboxfamedata',
    'user': 'root',
    'password': ''
}

# database_name = 'ainame'
# table_name_category = "category"
# table_name_query = "query_file"
# table_name_enquire = 'Enquire'
# password = "[MU%*t_;Uop!"

Extension_list = ['.com', '.net', '.org', '.io', '.co', '.us', '.info', '.site', '.biz', '.app', '.gov',
                  '.me', '.bar', '.edu', '.xyz',
                  '.tech']

# Object for Flask
app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/generate', methods=['POST', 'GET'])
def generate():
    logger.info("Inside generate")

    if request.method == 'POST':
        result = request.form.to_dict()
        # search  name
        keyword = result['keywords']
        input_text_list = keyword.split()
        input_text_list.append(keyword.replace(" ", ""))
        input_text_list = set(input_text_list)

        #  Category
        category = result['search_category'].replace("&", "and").replace(' ', "_")
        logger.info(category)
        if category == "" and keyword != "":
            logger.info("category is none and keyword is not none")
            error = "Category input is missing. Please select category for AI-based brand name."
            final = ""

        elif category != "" and keyword == "":
            logger.info("category is not none and keyword is none")
            error = "Keyword input is missing. Please enter keywords for AI-based brand name."
            final = ""

        elif category == "" and keyword == "":
            logger.info("category and keyword both none")
            error = "Category & Keyword  input is missing. Please enter Category & keywords for AI-based brand name."
            final = ""
        else:
            logger.info(f"category  is {category} and keyword is {keyword}")
            error = ''
            query = database_op.select_query(database_name, table_name_category, category, password)

            pre_res = [input_text.capitalize() + (sub.replace(' ', '')).capitalize() for sub in query if
                       sub != ''
                       for input_text in
                       input_text_list]
            suf_res = [(sub.replace(' ', '')).capitalize() + input_text.capitalize() for sub in query if
                       sub != ''
                       for input_text in
                       input_text_list]

            random.shuffle(pre_res)
            random.shuffle(suf_res)

            # shuffle
            main = pre_res + suf_res
            random.shuffle(main)
            logger.info("Shuffling done")

            final = main[0:150]

        field = (keyword, category)
        logger.info("query inserting into table query")

        database_op.insert_into_table_query(database_name, table_name_query, field, password)
        logger.info("query insertion into table query done")

        # 5. Display
        # return field
        return render_template('index.html', data=final, error=error,
                               category=category.replace("and", "&").replace('_', " "), text=keyword)


@app.route('/domain-generate/<domain_name>', methods=['POST', 'GET'])
def process(domain_name):
    domain_input = request.form.get('domain_input')
    logger.info("get domain_input ")
    logger.info("Availability check  of domain_input start ")
    domain = [[(domain_input + ex).lower(),
               domain_check.check_domain_availability((domain_input + ex).lower())] for ex in Extension_list]
    logger.info("Availability check  of name done and store in domain list ")
    # return f"Domain input received for form {index}: {domain_input}"
    # Perform further processing with the domain input
    return render_template('index.html', domain=domain, domain_input=domain_input)


@app.route('/thankyou', methods=['POST'])
def thankyou():
    # global name, sender_email, sender_password, subject, receiver_email, message, firstname, lastname, businesscategory, businessdetails, city, Country, email, know_us, website, phone
    if request.method == 'POST':
        result = request.form.to_dict()
        # search  name
        firstname = result['firstname']
        lastname = result['lastname']
        businesscategory = result['businesscategory']
        businessdetails = result['businessdetails']
        city = result['city']
        Country = result['Country']
        email = result['email']
        phone = result['phone']
        website = result['website']
        know_us = result['know_us']

        field = (firstname, lastname, businesscategory, businessdetails, city, Country, email, phone, website, know_us)
        database_op.insert_into_table_enquire(database_name, table_name_enquire, field, password)

        name = firstname + " " + lastname

        receiver_email = email
        subject = 'Thank you for filling out the form'
        message = f"""<!DOCTYPE html>
            <html>
            <head>
                <title>Thank You</title>
            </head>
            <body>
                <h2>Thank You, {name}</h2>
                <p>Thank you for choosing our brand naming services. We assure you that you are heading in the right direction. Our brand naming experts have worked hard to provide you with suitable names for your business.</p>
                <p>If you have any queries, please feel free to contact us using the information below:</p>
                <ul>
                    <li>Phone no.: <strong>09871446557</strong</li>
                    <li>Website: <strong><a href="http://www.unboxfame.com">www.unboxfame.com</a></strong></li>
                    <li>Address: <strong>133, 2nd Floor, Western Marg, Lane Number 1, Saidulajab, Saket, New Delhi, Delhi - 110030<strong></li>
                </ul>
                <p>Regards &amp; Thanks</p>
                <img src="cid:logo_image" alt='Unboxfame'>
                <p>Unboxfame</p>
                <p>Brand Naming Agency</p>
                <p>Logo Creation</p>
                <p>Digital Marketing 360&deg;</p>
                <p>Email: <a href="mailto:pragya@unboxfame.com">pragya@unboxfame.com</a></p>
                <p>Website: <a href="http://www.unboxfame.com">www.unboxfame.com</a></p>
                <a href="https://www.facebook.com/unboxfameofficial"><img src="cid:facebook_logo"></a>
                <a href="https://www.youtube.com/@unboxfameofficial"><img src="cid:youtube_logo"></a>
                <a href="https://www.linkedin.com/company/unboxfame"><img src="cid:linkedIn_logo"></a>
                <a href="https://www.instagram.com/unboxfameofficial"><img src="cid:instragram_logo"></a>
                <a href="https://in.pinterest.com/unboxfameofficial"><img src="cid:pinterest_logo"></a>
                <a href="https://twitter.com/Unbox_fame"><img src="cid:twitter_logo"></a>
            </body>
            </html>
            """
        send_mail.send_email(receiver_email, subject, message)
        logger.info(f"Mail send to {email} ")

        # list_receiver_email = ['pooja.das@unboxfame.com', 'mansoor@unboxfame.com', 'amitkumar@unboxfame.com']
        list_receiver_email = ['poojadas2014.pd@gmail.com']

        body = f"""
                <!DOCTYPE html>
                <html>
                <body>
                <head>
                <title>Enquire</title>
                </head>
                <h4>Hello Admin,</h4>
                <p><strong>New user {name} is Enquire about Brand name.</strong></p>
                <ul>
                    <li>firstname : {firstname}</li>
                    <li>lastname : {lastname}</li>
                    <li>businesscategory :{businesscategory}</li>
                    <li>businessdetails : {businessdetails}</li>
                    <li>city : {city}</li>
                    <li>Country : {Country}</li>
                    <li>email : {email}</li>
                    <li>phone : {phone}</li>
                    <li>website : {website}</li>
                    <li>know_us : {know_us}</li>
                </ul>
                </body>
                </html>
            """
        for receiver_email in list_receiver_email:
            receive_mail.receive(receiver_email, body)

        logger.info(f"done to admin")
        logger.info(f"Mail send to admin ")

        return render_template('thankyou.html', name=name)


@app.route('/category-name-generator', methods=['POST', 'GET'])
def category():
    if request.method == 'POST':
        category = request.form['category'].lower().strip()
        return redirect(url_for('category_page', category=category))
    return render_template('category.html')


@app.route('/category-name-generator/<category>')
def category_page(category):
    # Logic for category.html goes here

    global main_block, question1, question4, question3, answer2, answer3, answer4, answer5, answer1, question2, question5, category_name, title, otherMeta, keywords, description
    connection = con.connect(**db_config)
    cursor = connection.cursor()
    cursor.execute(f"SELECT * FROM pages WHERE category = '{category}'")

    rows = cursor.fetchall()
    cursor.close()
    connection.close()

    # Process the fetched data
    for row in rows:
        category_name = row[0]
        title = row[1]
        description = row[2].strip()
        keywords = row[3].strip()
        otherMeta = row[4]
        main_block = row[5]
        question1 = row[6]
        answer1 = row[7]
        question2 = row[8]
        answer2 = row[9]
        question3 = row[10]
        answer3 = row[11]
        question4 = row[12]
        answer4 = row[13]
        question5 = row[14]
        answer5 = row[15]

    return render_template('category.html', category=category, category_name=category_name, title=title,
                           description=description, keywords=keywords, otherMeta=otherMeta, main_block=main_block,
                           question1=question1, question2=question2, question3=question3, question4=question4,
                           question5=question5, answer1=answer1, answer2=answer2, answer3=answer3, answer4=answer4,
                           answer5=answer5)


@app.route('/category-name-generator/generate/<sub_cat>', methods=['POST', 'GET'])
def sub_generate(sub_cat):
    logger.info("Inside generate")

    if request.method == 'POST':
        result = request.form.to_dict()
        # search name
        keyword = result['keywords']
        input_text_list = keyword.split()
        input_text_list.append(keyword.replace(" ", ""))
        input_text_list = set(input_text_list)

        # Category
        category_sub = result['search_category']
        if category_sub == "" and keyword != "":
            logger.info("category is none and keyword is not none")
            error = "Category input is missing. Please select a category for AI-based brand name."
            final = ""

        elif category_sub != "" and keyword == "":
            logger.info("category is not none and keyword is none")
            error = "Keyword input is missing. Please enter keywords for an AI-based brand name."
            final = ""

        elif category_sub == "" and keyword == "":
            logger.info("category and keyword both none")
            error = "Category & Keyword input is missing. Please enter Category & keywords for an AI-based brand name."
            final = ""
        else:
            logger.info(f"category is {category_sub} and keyword is {keyword}")
            error = ''

            # Fetch the details from the 'pages' table
            connection = con.connect(**db_config)
            cursor = connection.cursor()
            cursor.execute("SELECT * FROM pages WHERE category = %s", (category_sub,))

            rows = cursor.fetchall()
            cursor.close()
            connection.close()

            # Process the fetched data
            if rows:
                row = rows[0]  # Assuming only one row is expected for the given category
                category_name = row[0]
                title = row[1]
                description = row[2].strip()
                keywords = row[3].strip()
                otherMeta = row[4]
                main_block = row[5]
                question1 = row[6]
                answer1 = row[7]
                question2 = row[8]
                answer2 = row[9]
                question3 = row[10]
                answer3 = row[11]
                question4 = row[12]
                answer4 = row[13]
                question5 = row[14]
                answer5 = row[15]
            else:
                # Handle the case where no rows are found for the given category
                category_name = ""
                title = ""
                description = ""
                keywords = ""
                otherMeta = ""
                main_block = ""
                question1 = ""
                answer1 = ""
                question2 = ""
                answer2 = ""
                question3 = ""
                answer3 = ""
                question4 = ""
                answer4 = ""
                question5 = ""
                answer5 = ""

            query = database_op.select_query(database_name, table_name_category, category_sub, password)

            pre_res = [input_text.capitalize() + (sub.replace(' ', '')).capitalize() for sub in query if
                       sub != ''
                       for input_text in
                       input_text_list]
            suf_res = [(sub.replace(' ', '')).capitalize() + input_text.capitalize() for sub in query if
                       sub != ''
                       for input_text in
                       input_text_list]

            random.shuffle(pre_res)
            random.shuffle(suf_res)

            # shuffle
            main = pre_res + suf_res
            random.shuffle(main)
            logger.info("Shuffling done")

            final = main[0:150]

        field = (keyword, category_sub)
        logger.info("query inserting into table query")

        database_op.insert_into_table_query(database_name, table_name_query, field, password)
        logger.info("query insertion into table query done")

        # 5. Display
        return render_template('category.html', data=final, error=error, category_sub=category_sub, text=keyword,
                               category=category_name, title=title, description=description,
                               keywords=keywords, otherMeta=otherMeta, main_block=main_block,
                               question1=question1, question2=question2, question3=question3, question4=question4,
                               question5=question5, answer1=answer1, answer2=answer2, answer3=answer3, answer4=answer4,
                               answer5=answer5)


@app.route('/category-name-generator/generate/<sub>/domain-generate/<domain_name>', methods=['POST', 'GET'])
def process_sub(sub, domain_name):
    domain_input = request.form.get('domain_input')
    logger.info("get domain_input ")
    logger.info("Availability check of domain_input start ")
    domain = [[(domain_input + ex).lower(),
               domain_check.check_domain_availability((domain_input + ex).lower())] for ex in Extension_list]
    logger.info("Availability check of name done and store in domain list ")

    # Fetch the details from the 'pages' table
    connection = con.connect(**db_config)
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM pages WHERE category = %s", (sub,))

    rows = cursor.fetchall()
    cursor.close()
    connection.close()

    # Process the fetched data
    if rows:
        row = rows[0]  # Assuming only one row is expected for the given category
        category_name = row[0].lower()
        title = row[1]
        description = row[2]
        keywords = row[3]
        otherMeta = row[4]
        main_block = row[5]
        question1 = row[6]
        answer1 = row[7]
        question2 = row[8]
        answer2 = row[9]
        question3 = row[10]
        answer3 = row[11]
        question4 = row[12]
        answer4 = row[13]
        question5 = row[14]
        answer5 = row[15]
    else:
        # Handle the case where no rows are found for the given category
        category_name = ""
        title = ""
        description = ""
        keywords = ""
        otherMeta = ""
        main_block = ""
        question1 = ""
        answer1 = ""
        question2 = ""
        answer2 = ""
        question3 = ""
        answer3 = ""
        question4 = ""
        answer4 = ""
        question5 = ""
        answer5 = ""

    # Perform further processing with the domain input
    return render_template('category.html', domain=domain, domain_input=domain_input,
                           category=category_name, title=title, description=description,
                           keywords=keywords, otherMeta=otherMeta, main_block=main_block,
                           question1=question1, answer1=answer1, question2=question2, answer2=answer2,
                           question3=question3, answer3=answer3, question4=question4, answer4=answer4,
                           question5=question5, answer5=answer5)


@app.route('/book', methods=['POST', 'GET'])
def book_form():
    domain = request.form['domain']
    name = request.form.get('name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    city = request.form.get('city')
    country = request.form.get('country')

    field = (domain, name, email, phone, city, country)
    logger.info("query inserting into table query")
    database_op.insert_into_table_query(database_name, table_name_book, field, password)
    logger.info("query insertion into table query done")

    # mail section for booking starting from here
    receiver_email = email
    subject = 'Thank you for booking Domain '
    message = f"""<!DOCTYPE html>
             <html>
             <head>
                 <title>Thank You</title>
             </head>
             <body>
                  <h1>Thank You {name}</h1>
                    <p>Thank you for going to the customized brand name for your business. We can assure you that you are in the right direction. We hope you will be satisfied with the names given by our brand naming experts.</p>
                    <p>Although our free business name generator also produces the brand name as per your interest, going with a customized brand name is the right option as we can guarantee that the customized name will be domain and trademark available. We know you don’t want a name already available on the market for your business.</p>
                    <p><strong><i>Our Brand Naming Experts will connect with you shortly.</i></strong></p>
                    <a href="https://www.unboxfame.com/ai-business-name-generator/" class="btn">Go Back</a>

                 <p>Regards &amp; Thanks</p>
                 <img src="cid:logo_image" alt='Unboxfame'>
                 <p>Unboxfame</p>
                              </body>
             </html>
             """
    send_mail.send_email(receiver_email, subject, message)
    logger.info(f"Mail send to {email} ")

    # list_receiver_email = ['pooja.das@unboxfame.com', 'mansoor@unboxfame.com', 'amitkumar@unboxfame.com']
    receiver_email = ['poojadas2014.pd@gmail.com']

    body = f"""
                 <!DOCTYPE html>
                 <html>
                 <body>
                 <head>
                 <title>Enquire</title>
                 </head>
                 <h4>Hello Admin,</h4>
                 <p><strong>New user {name} is Enquire about Brand name.</strong></p>
                 <ul>
                     <li>Name : {name}</li>
                     <li>Domain : {domain}</li>
                     <li>city : {city}</li>
                     <li>Country : {country}</li>
                     <li>email : {email}</li>
                     <li>phone : {phone}</li> 
                 </ul>
                 </body>
                 </html>
             """

    receive_mail.receive(receiver_email, body)

    logger.info(f"done to admin")
    logger.info(f"Mail send to admin ")
    return render_template('book_thankyou.html')


@app.route('/perfume')
def perfume():
    return render_template('perfume.html')


@app.route('/perfume/generate', methods=['POST', 'GET'])
def perfume_generate():
    logger.info("Inside generate")

    if request.method == 'POST':
        result = request.form.to_dict()
        # search  name
        keyword = result['keywords']
        input_text_list = keyword.split()
        input_text_list.append(keyword.replace(" ", ""))
        input_text_list = set(input_text_list)

        #  Category
        category = result['search_category']
        if category == "" and keyword != "":
            logger.info("category is none and keyword is not none")
            error = "Category input is missing. Please select category for AI-based brand name."
            final = ""

        elif category != "" and keyword == "":
            logger.info("category is not none and keyword is none")
            error = "Keyword input is missing. Please enter keywords for AI-based brand name."
            final = ""

        elif category == "" and keyword == "":
            logger.info("category and keyword both none")
            error = "Category & Keyword  input is missing. Please enter Category & keywords for AI-based brand name."
            final = ""
        else:
            logger.info(f"category  is {category} and keyword is {keyword}")
            error = ''
            query = database_op.select_query(database_name, table_name_category, category, password)

            pre_res = [input_text.capitalize() + (sub.replace(' ', '')).capitalize() for sub in query if
                       sub != ''
                       for input_text in
                       input_text_list]
            suf_res = [(sub.replace(' ', '')).capitalize() + input_text.capitalize() for sub in query if
                       sub != ''
                       for input_text in
                       input_text_list]

            random.shuffle(pre_res)
            random.shuffle(suf_res)

            # shuffle
            main = pre_res + suf_res
            random.shuffle(main)
            logger.info("Shuffling done")

            final = main[0:150]

        field = (keyword, category)
        logger.info("query inserting into table query")

        database_op.insert_into_table_query(database_name, table_name_query, field, password)
        logger.info("query insertion into table query done")

        # 5. Display
        # return field
        return render_template('perfume.html', data=final, error=error, category=category, text=keyword)


@app.route('/perfume/<domain_name>', methods=['POST', 'GET'])
def perfume_process(domain_name):
    domain_input = request.form.get('domain_input')
    logger.info("get domain_input ")
    logger.info("Availability check  of domain_input start ")
    domain = [[(domain_input + ex).lower(),
               domain_check.check_domain_availability((domain_input + ex).lower())] for ex in Extension_list]
    logger.info("Availability check  of name done and store in domain list ")
    # return f"Domain input received for form {index}: {domain_input}"
    # Perform further processing with the domain input
    return render_template('perfume.html', domain=domain, domain_input=domain_input)


secret_key = secrets.token_hex(16)
# logger.info(secret_key)


app.secret_key = secret_key

# Database connection configuration
db_config = {
    'host': 'localhost',
    'database': 'Unboxfamedata',
    'user': 'root',
    'password': ''
}

db_config_category = {
    'host': 'localhost',
    'database': 'categorydata',
    'user': 'root',
    'password': ''
}


def connection_db():
    try:
        mydb = con.connect(host='localhost',
                           user='root',
                           password='',
                           database='Unboxfamedata')
        logger.info(f"Connected with database Unboxfamedata established successfully...")
    except ConnectionError:
        logger.info("Error while connecting to database: %s" % ConnectionError)
        raise ConnectionError
    return mydb


def insert(table_name, field):
    try:
        logger.info(f'Inserting start on table {table_name}')
        # mydb = connection_db()
        connection = con.connect(**db_config)

        query = f"INSERT INTO users VALUES {field}"
        cursor = connection.cursor()
        cursor.execute(query)
        connection.commit()
        cursor.close()
        connection.close()
        logger.info(f"Insertion done on table uses ")
    except Error as e:
        logger.info("Error connecting to MySQL database:", e)


def authenticate(username):
    try:
        connection = con.connect(**db_config)
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()
        cursor.close()
        connection.close()
        return user
    except Error as e:
        logger.info("Error connecting to MySQL database:", e)
        return None


def user_exists(username):
    # Connect to the MySQL database
    db = connection_db()
    # Create a cursor to execute SQL queries
    cursor = db.cursor()

    # Prepare the SQL query to check if the user exists
    query = "SELECT COUNT(*) FROM users WHERE username = %s"
    cursor.execute(query, (username,))

    # Fetch the result
    result = cursor.fetchone()

    # Close the database connection
    cursor.close()
    db.close()

    # Check if the user count is greater than 0
    if result and result[0] > 0:
        return True
    else:
        return False


# ______________________________________________ || LOGIN ||_____________________________________________________________

# ********************************************* First page *******************************************
# Define a route to render the HTML form
@app.route("/admin")
def admin():
    return render_template("login.html")


# ********************************************* Login PAGE*****************************************
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    user = authenticate(username)

    if user:
        if password == user['password']:
            role = user['role']
            user_type = user['user_type']
            if role == 'Data_Entry' and user_type == 'Brand_Name':
                session['username'] = username
                return redirect('/admin/dashboard')

            elif role == 'Manager' and user_type == 'Brand_Name':
                session['username'] = username
                return redirect('/admin/dashboard')

            elif role == 'Page_Editor' and user_type == 'Page_modification':
                session['username'] = username
                return redirect('/admin/dashboard')

            elif role == 'Page_Manager' and user_type == 'Page_modification':
                session['username'] = username
                return redirect('/admin/dashboard')

            elif role == 'Super_admin' and user_type == 'Super_admin':
                session['username'] = username  # Store the username in the session
                return redirect('/admin/dashboard')

    flash('Invalid username or password', 'error')
    return redirect('/admin')


def get_user_type(username):
    # Retrieve the user type based on the provided username
    # Replace this with your own logic to fetch the user type
    # Here's a placeholder implementation:
    user = authenticate(username)  # Replace with your logic to fetch user details by username

    if user:
        return user['user_type']

    return None


def get_role(username):
    # Retrieve the role based on the provided username
    # Replace this with your own logic to fetch the role
    # Here's a placeholder implementation:
    user = authenticate(username)  # Replace with your logic to fetch user details by username

    if user:
        return user['role']

    return None


# ______________________________________________ || DASHBOARD ||_____________________________________________________________

# *********************************************|| Add user ||***************************************
@app.route("/admin/dashboard/add_user", methods=["POST"])
def add_user():
    username = request.form["username"]
    firstname = request.form["firstname"]
    lastname = request.form["lastname"]
    email = request.form["email"]
    password = request.form["password"]
    user_type = request.form["user_type"]
    role = request.form["role"]
    try:
        # Check if the user already exists in the database
        if user_exists(username):
            flash('User already exists!', 'error')
        else:
            # Store data in MySQL database
            values = (username, firstname, lastname, email, password, user_type, role)
            insert(table_name='users', field=values)
            flash('User created successfully!', 'success')

    except Exception as e:
        flash('An error occurred: {}'.format(str(e)), 'error')

    return redirect("/admin/dashboard")


# ***********************************************|| All User ||***********************************************
def alluser():
    # all user from the database
    connection = con.connect(**db_config)
    cursor = connection.cursor()
    select_query = f'SELECT * FROM users'
    cursor.execute(select_query)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    return result


def allpage():
    connection = con.connect(**db_config)
    cursor = connection.cursor()
    select_query = f'SELECT * FROM pages'
    cursor.execute(select_query)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    return result


def allCategorypage():
    connection = con.connect(**db_config)
    cursor = connection.cursor()
    select_query = f'SELECT category FROM pages'
    cursor.execute(select_query)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    return result


# -------------------------------------------|| Main Dashboard.html ||--------------------------------------
@app.route('/admin/dashboard')
def dashboard():
    records = alluser()
    page_all = allpage()
    allCategory = allCategorypage()
    category_list = table_list() if table_list() else []
    username = session.get('username')  # Retrieve the username from the session

    if username and records and page_all and allCategory:
        # Retrieve the first record from the list
        user_type = get_user_type(username)  # Replace this with your logic to retrieve user type
        role = get_role(username)
        record = records if records else []
        page = page_all if page_all else []  # Set an empty list if page_all is None
        category_all = allCategory if allCategory else []

        # Pass the data to the template for rendering
        return render_template("dashboard.html", page=page, category_all=category_all, record=record,
                               category_list=category_list, username=username, user_type=user_type, role=role)

    # Handle the case when no records are found or username is not set
    return redirect('/admin')


# ************************************|| Edit User ||**********************************************
@app.route('/admin/dashboard/edit_user', methods=['POST'])
def edit_database():
    username = request.form["edit-username"]
    firstname = request.form["edit-firstname"]
    lastname = request.form["edit-lastname"]
    email = request.form["edit-email"]
    password = request.form["edit-password"]
    user_type = request.form["edit-user-type"]
    role = request.form["edit-role"]

    connection = con.connect(**db_config)
    cursor = connection.cursor()
    select_query = f"""UPDATE users SET firstname ='{firstname}',
                                        lastname='{lastname}',
                                        email='{email}',
                                        password='{password}',
                                        user_type='{user_type.replace(" ", "_")}',
                                        role='{role.replace(" ", "_")}'
                where username='{username}'"""
    cursor.execute(select_query)

    connection.commit()
    cursor.close()

    flash('User Update successfully!', 'success')

    return redirect("/admin/dashboard")


# **********************************|| Delete User ||*************************************************

@app.route('/admin/dashboard/delete_user', methods=['POST'])
def delete_user():
    username = request.form.get('username')
    try:
        # Delete the row from the table
        connection = con.connect(**db_config)
        cursor = connection.cursor()
        delete_query = f'DELETE FROM users WHERE username = "{username}"'
        cursor.execute(delete_query)
        connection.commit()
        cursor.close()
        flash('User deleted successfully!', 'success')
        return redirect("/dashboard")
    except Exception as e:
        flash(f"Failed to delete User {username}.", 'error')
    return redirect('/admin/dashboard')


# *****************************************|| Add Brand Name ||********************************************************#
def create_table(table_name):
    cnx = con.connect(**db_config_category)
    cursor = cnx.cursor()

    # Check if the table already exists
    cursor.execute(f"SHOW TABLES LIKE '{table_name}'")
    table_exists = cursor.fetchone()

    # If the table doesn't exist, create it
    if not table_exists:
        create_table_query = f"""
          CREATE TABLE {table_name} (
            Brand_Name VARCHAR(100),
            Price INT,
            Description VARCHAR(500),
            Tagline VARCHAR(100),
            Domain_availability VARCHAR(50),
            Trademark_availability VARCHAR(50),
            DateAdded DATE
        );

        """
        cursor.execute(create_table_query)
        cnx.commit()
        return True

    cursor.close()
    cnx.close()
    return False


def table_list():
    cnx = con.connect(**db_config_category)
    cursor = cnx.cursor()

    # Check if the table already exists
    cursor.execute(f"SHOW TABLES;")
    table_exist = cursor.fetchall()
    cursor.close()
    cnx.close()
    table_list_all = [col.capitalize().replace('and', '&').replace('_', ' ') for row in table_exist for col in row]

    return table_list_all


def insert_data(table_name, Brand_Name, Price, description, tagline, domainAvailability, trademarkAvailability,
                DateAdded):
    cnx = con.connect(**db_config_category)
    cursor = cnx.cursor()

    # Insert data into the table
    insert_data_query = f"""
    INSERT INTO {table_name} (Brand_Name,Price, Description, tagline, Domain_availability, Trademark_availability,DateAdded)
    VALUES (%s, %s,%s, %s, %s, %s,%s)
    """
    data_values = (Brand_Name, Price, description, tagline, domainAvailability, trademarkAvailability, DateAdded)
    cursor.execute(insert_data_query, data_values)
    cnx.commit()
    cursor.close()
    cnx.close()


@app.route('/admin/dashboard/add_brand_name', methods=['GET', 'POST'])
def add_brand_name():
    if request.method == 'POST':
        # Get form data
        table_name = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')
        Brand_Name = request.form['brandName'].capitalize()
        Price = request.form["price"]
        description = request.form['description'].capitalize()
        tagline = request.form['tagline'].capitalize()
        domainAvailability = request.form['domainAvailability']
        trademarkAvailability = request.form['trademarkAvailability']
        DateAdded = date.today()
        try:
            # Insert data into the table
            insert_data(table_name, Brand_Name, Price, description, tagline, domainAvailability,
                        trademarkAvailability, DateAdded)

            flash(
                f"Data inserted into table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully.",
                'success')
        except:
            flash(f"'{table_name.capitalize().replace('and', '&').replace('_', ' ')}' not present", 'error')

        return redirect('/admin/dashboard')

    return redirect('/admin/dashboard')


# **********************************************|| Add Category ||**********************************************************

@app.route('/admin/dashboard/add_category', methods=['GET', 'POST'])
def add_category():
    if request.method == 'POST':
        table_name = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')
        # Create table if it doesn't exist
        table_created = create_table(table_name)

        if table_created:
            flash(f"Table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' created successfully",
                  'success')
        else:
            flash(f"Table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' already Exit", 'error')

        return redirect('/admin/dashboard')

    return redirect('/admin/dashboard')


# **********************************************|| Edit Brand Name ||**********************************************************

@app.route('/admin/dashboard/edit_brand_name', methods=['GET', 'POST'])
def edit_brand_name():
    if request.method == 'POST':
        # Get form data
        table_name = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')
        oldbrand_name = request.form['oldbrandName'].capitalize()
        newbrand_name = request.form['newbrandName'].capitalize()
        description = request.form['description'].capitalize()
        Price = request.form["price"]
        tagline = request.form['tagline'].capitalize()
        domain_availability = request.form['domainAvailability'].lower()
        trademark_availability = request.form['trademarkAvailability'].lower()

        if newbrand_name == "":
            newbrand_name = oldbrand_name
        else:
            newbrand_name = newbrand_name

        # Check if brand name exists in the table
        connection = con.connect(**db_config_category)
        cursor = connection.cursor()
        select_query = f"SELECT * FROM {table_name} WHERE Brand_Name = '{oldbrand_name}';"
        cursor.execute(select_query)
        brand = cursor.fetchone()

        if brand is None:
            flash(
                f"'{oldbrand_name}' not found in table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}'",
                'error')
        else:
            # Update data in the table
            try:
                update_query = f"""UPDATE {table_name} SET
                                    Brand_Name='{newbrand_name}',
                                    Price='{price}',
                                    Description='{description}',
                                    Tagline='{tagline}',
                                    Domain_availability='{domain_availability}',
                                    Trademark_availability='{trademark_availability}'
                                    WHERE Brand_Name ='{oldbrand_name}';"""
                cursor.execute(update_query)
                connection.commit()
                cursor.close()
                flash(
                    f"Edit '{newbrand_name}' on '{table_name.capitalize().replace('and', '&').replace('_', ' ')}' successfully.",
                    'success')
            except Exception as e:
                flash(
                    f"An error occurred while updating '{oldbrand_name}' in table '{table_name.capitalize().replace('and', '&').replace('_', ' ')}': {str(e)}",
                    'error')
        connection.close()

    return redirect('/admin/dashboard')


# ****************************************|| Page Editor ||*******************************************************
@app.route('/admin/dashboard/page_editor', methods=['GET', 'POST'])
def page_editor():
    if request.method == 'POST':
        # Get form data

        category = request.form['category'].capitalize().replace('&', 'and').replace(' ', '_')

        title = request.form['Title']
        description = request.form['Description']
        keywords = request.form['Keywords']
        otherMeta = request.form['Other_Meta']
        mainBlock = request.form['Main_block']
        question1 = request.form['Question1']
        answer1 = request.form['Answer1']
        question2 = request.form['Question2']
        answer2 = request.form['Answer2']
        question3 = request.form['Question3']
        answer3 = request.form['Answer3']
        question4 = request.form['Question4']
        answer4 = request.form['Answer4']
        question5 = request.form['Question5']
        answer5 = request.form['Answer5']

        field = (
            category, title, description, keywords, otherMeta, mainBlock, question1, answer1, question2, answer2,
            question3, answer3, question4, answer4,
            question5,
            answer5)

        connection = con.connect(**db_config)
        cursor = connection.cursor()

        select_query = f"SELECT * FROM pages WHERE category = '{category}';"
        cursor.execute(select_query)
        category_SEL = cursor.fetchone()

        if category_SEL is None:
            query = f'INSERT INTO pages VALUES {field} '
            cursor.execute(query)
            connection.commit()
            cursor.close()
            flash(
                f"Content of '{category.capitalize().replace('and', '&').replace('_', ' ')}' successfully Inserted into Page.",
                'success')

        else:
            flash(
                f"'{category.capitalize().replace('and', '&').replace('_', ' ')}' already have its  Content. For edit go to Page Modifier or contact your Page Manager",
                'error')

    return redirect('/admin/dashboard')


# ****************************************|| Page Modification ||*******************************************************
@app.route('/admin/dashboard/page_modification', methods=['GET', 'POST'])
def page_modification():
    if request.method == 'POST':
        # Get form data
        table_name = 'pages'
        category = request.form['record-id'].capitalize().replace('&', 'and').replace(' ', '_')

        title = request.form['title']
        description = request.form['description']
        keywords = request.form['keywords']
        otherMeta = request.form['other-meta']
        mainBlock = request.form['main-block']
        question1 = request.form['question1']
        answer1 = request.form['answer1']
        question2 = request.form['question2']
        answer2 = request.form['answer2']
        question3 = request.form['question3']
        answer3 = request.form['answer3']
        question4 = request.form['question4']
        answer4 = request.form['answer4']
        question5 = request.form['question5']
        answer5 = request.form['answer5']

        field = (
            category, title, description, keywords, otherMeta, mainBlock, question1, answer1, question2, answer2,
            question3, answer3, question4, answer4,
            question5,
            answer5)

        connection = con.connect(**db_config)
        cursor = connection.cursor()

        select_query = f"SELECT * FROM pages WHERE category = '{category}';"
        cursor.execute(select_query)
        category_SEL = cursor.fetchone()

        if category_SEL is None:
            query = f'INSERT INTO pages VALUES {field} '
            cursor.execute(query)
            connection.commit()
            cursor.close()
            flash(
                f"Modify '{category.capitalize().replace('and', '&').replace('_', ' ')}' on '{table_name}' successfully.",
                'success')

        else:
            # Update data in the table
            query_del = f"DELETE FROM `pages` WHERE category='{category}';"
            cursor.execute(query_del)
            query = f'INSERT INTO pages VALUES {field}'
            cursor.execute(query)
            connection.commit()
            cursor.close()
            flash(
                f"Modify '{category.capitalize().replace('and', '&').replace('_', ' ')}' on '{table_name}' successfully.",
                'success')

    return redirect('/admin/dashboard')


# ******************************************|| Delete Page ||*************************************************************
@app.route('/admin/dashboard/delete_page', methods=['POST'])
def delete_page():
    category = request.form['category'].replace('&', 'and').replace(' ', '_')
    try:
        # Delete the row from the table
        connection = con.connect(**db_config)
        cursor = connection.cursor()
        delete_query = f"DELETE FROM pages WHERE category = '{category}'"
        cursor.execute(delete_query)
        connection.commit()
        cursor.close()
        flash(f"Successfully deleted page for category '{category.replace('and', '&').replace('_', ' ')}'.", 'success')
    except Exception:
        flash(f"Failed to delete page for category '{category.replace('and', '&').replace('_', ' ')}'.", 'error')
    return redirect('/admin/dashboard')


if __name__ == "__main__":
    app.run(debug=True, host='localhost')
