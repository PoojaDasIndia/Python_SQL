import random
from flask import Flask, render_template, request, redirect, url_for
from database import database_op
from apps import send_mail, receive_mail
from apps import domain_check
from core import logger
import mysql.connector as con
# import openai
logger = logger.create_logger("app")

database_name = "UnboxfameData"
table_name_category = "category"
table_name_query = "query_file"
table_name_enquire = 'Enquire'
table_name_book = "Domain_Enquire"
password = ""

db_config = {
    'host': 'localhost',
    'database': 'Unboxfamedata',
    'user': 'root',
    'password': ''
}

# database_name = 'ainame'
# table_name_category = "category"
# table_name_query = "query_file"
# table_name_enquire = 'Enquire'
# password = "[MU%*t_;Uop!"

Extension_list = ['.com', '.net', '.org', '.io', '.co', '.us', '.info', '.site', '.biz', '.app', '.gov',
                  '.me', '.bar', '.edu', '.xyz',
                  '.tech']


# Set up your OpenAI API credentials
# openai.api_key = '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'


def generate_brand_names(description):
    prompt = f"Generate 100 brand names related to the user's description: '{description}'."

    # Check if country is mentioned in the description
    if "country" in description:
        prompt += " If a country is mentioned, provide the brand names in the local language."
    else:
        prompt += " Otherwise, generate brand names without any specific requirements."

    # Check if the description is related to a holy book
    if "holy book" in description:
        prompt += " If the description is related to a holy book, include brand names related to religious themes."

    # Generate brand names using ChatGPT
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=200,
        n=100,  # Generate 100 brand names
        stop=None,
        temperature=0.8,
        top_p=1.0,
        frequency_penalty=0.0,
        presence_penalty=0.0
    )

    brand_names = []
    for choice in response.choices:
        text = choice.text.split('\n')
        names = [line.strip()[3:].strip() for line in text if line.strip()]
        brand_names.extend(names)  # Append the names to the list

    return brand_names[:150]  # Return the first 100 brand names


# Object for Flask
app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/generate', methods=['POST', 'GET'])
def generate():
    if request.method == 'POST':
        result = request.form.to_dict()
        # search  name
        description = result['keywords']

        #  Category

        if description == "":
            error = "Description  is missing. Please give description for AI-based brand name."
            name = None

        else:
            print(description)
            name = ['Al-Baik Tea', "Arabian' Aroma", 'Halal Tea House', 'Tannour Tea', 'Tea of the Desert', 'Um-Alqura Tea', 'Qatif Tea', 'Medina Mint Tea', 'Riyadh Roast', 'Jeddah Java', 'Diriyah Delight', 'Al-Shalateen Tea', 'Al-Qassim Tea', 'Jubail Java', 'Makkah Masala', 'Asir Tea', 'Al-Hasa Tea', 'Taif Tea', "Ta'if Turmeric Tea", 'Abha Amber Tea', 'Najran Nectar', 'Buraidah Black Tea', 'Khamis Tea', 'Al-Ghat Tea', 'Red Desert Tea', 'Arabian Nights Tea', 'Sand Tea', 'Customs of Saudi Tea', 'Tea of Arabia', 'Oasis Tea', 'Tea of the Kings', 'Middle East Tea', 'Tea of the Bedouin', 'Desert Sip', 'Arabian Floral Tea', 'Teatopia', 'Tribe Tea', 'Medina Tea', 'Royal Tea', "King's Blend", 'Saudi Spice Tea', 'Tea of the Sultan', 'Kingdom Tea', 'Tea of the Desert', 'OudTea', 'Bustan Tea', 'Bedouin Brew', "Sultan's Tea", 'Medina Treat', 'Camel Tea', 'Desert Wind Tea', 'Tea of the Dunes', 'Al Masmak Tea', 'Riyadh Tea', 'Tea of the Sand', 'Kingdom Blend', '', 'Tea Traditions of Saudi Arabia', 'Tea Mecca', 'Kaff Binti', 'Tea of Arabians', 'Arabian Tea Emporium', 'Tea Caravan', 'Tea Oasis', 'Arabian Chai', 'Qahwa', 'Tea of the Desert', "Naji's Tea", 'Arabian Teatopia', 'Saudiva', 'Kaff Sahar', 'Chai Wadi', 'Tea Haven', 'Arabian Tea Time', 'Sand Tea', 'Tea Spice of Arabia', 'Arabian Tea Bazaar', 'Desert Brewing', 'Nejm Tea', 'Tea of Arabia', 'Chai Arabia', 'Arabian Steep', 'Desert Tealicious', 'Arabian Tea House', 'Dar Chai', 'Tea of the Sands', 'Tea of Al-Najd', '', 'Saudi Tea Traditions', 'The Tea of Arabia', 'Sip of Saud', "Chai n' Saud", 'Chai Culture', "Tea K'halili", 'The Gathering Place', 'Al Zaytun Tea', "Al'Dahab Tea", 'Arabian Spice Tea', 'Royal Tea House', 'Supper Tea Time', 'The Arabian Chai', 'Al-Saha Tea', 'Arabian Charm Tea', 'The Tea Spot', 'Tea Shaan', 'The Eastern Kingdom Tea', 'Aroma of Arabia', 'Noon Tea', 'Arabian Flaire Tea', 'Green Gold Tea', 'Arabian Nights Tea', 'Arabian Elixir Tea', 'Joyful Tea Time', 'Tea of', 'Arabian Chai', 'Bedouin Tea', "Ka'aba Infusions", 'Hijaz Herbal', 'Desert Spice', 'Buraydah Brew', 'Jeddah Blend', 'Riyadh Roast', 'Al-Ahsa Aroma', 'Taif Teapot', 'Qatif Tea Time', 'Jubail Java', 'Al-Hasa Harvest', 'Baha Bazaar', 'Abha Aroma', 'Al-Kharj Kettle', 'Madinah Morning', 'Al-Qassim Quench', 'Najran Nectar', 'Al-Jouf Juice', 'Najd Elixir', 'Asir Afternoon', 'Jizan Jade', 'Makkah', 'Saudi Spice Tea', 'Arabian Tea Traditions', 'SaharTea', 'Tea of the Saudi Desert', 'The Tea House of Arabia', 'AlJinanTea', 'Royal Sand Tea', 'Desi Darjeeling', 'Bedouin Brew', 'Bint-Al-Kashmir', 'MandarTea', 'Saudi Samovar']
            # brand_names = generate_brand_names(description)
            # name = [i for i in brand_names if i != ""]
            error = ''
            # return field
        return render_template('index.html', data=name, error=error)

@app.route('/domain-generate/<domain_name>', methods=['POST', 'GET'])
def process(domain_name):
    domain_input = request.form.get('domain_input')
    logger.info("get domain_input ")
    logger.info("Availability check  of domain_input start ")
    domain = [[(domain_input + ex).lower(),
               domain_check.check_domain_availability((domain_input + ex).lower())] for ex in Extension_list]
    logger.info("Availability check  of name done and store in domain list ")
    # return f"Domain input received for form {index}: {domain_input}"
    # Perform further processing with the domain input
    return render_template('index.html', domain=domain, domain_input=domain_input)


@app.route('/thankyou', methods=['POST'])
def thankyou():
    # global name, sender_email, sender_password, subject, receiver_email, message, firstname, lastname, businesscategory, businessdetails, city, Country, email, know_us, website, phone
    if request.method == 'POST':
        result = request.form.to_dict()
        # search  name
        firstname = result['firstname']
        lastname = result['lastname']
        businesscategory = result['businesscategory']
        businessdetails = result['businessdetails']
        city = result['city']
        Country = result['Country']
        email = result['email']
        phone = result['phone']
        website = result['website']
        know_us = result['know_us']

        field = (firstname, lastname, businesscategory, businessdetails, city, Country, email, phone, website, know_us)
        database_op.insert_into_table_enquire(database_name, table_name_enquire, field, password)

        name = firstname + " " + lastname

        receiver_email = email
        subject = 'Thank you for filling out the form'
        message = f"""<!DOCTYPE html>
            <html>
            <head>
                <title>Thank You</title>
            </head>
            <body>
                <h2>Thank You, {name}</h2>
                <p>Thank you for choosing our brand naming services. We assure you that you are heading in the right direction. Our brand naming experts have worked hard to provide you with suitable names for your business.</p>
                <p>If you have any queries, please feel free to contact us using the information below:</p>
                <ul>
                    <li>Phone no.: <strong>09871446557</strong</li>
                    <li>Website: <strong><a href="http://www.unboxfame.com">www.unboxfame.com</a></strong></li>
                    <li>Address: <strong>133, 2nd Floor, Western Marg, Lane Number 1, Saidulajab, Saket, New Delhi, Delhi - 110030<strong></li>
                </ul>
                <p>Regards &amp; Thanks</p>
                <img src="cid:logo_image" alt='Unboxfame'>
                <p>Unboxfame</p>
                <p>Brand Naming Agency</p>
                <p>Logo Creation</p>
                <p>Digital Marketing 360&deg;</p>
                <p>Email: <a href="mailto:pragya@unboxfame.com">pragya@unboxfame.com</a></p>
                <p>Website: <a href="http://www.unboxfame.com">www.unboxfame.com</a></p>
                <a href="https://www.facebook.com/unboxfameofficial"><img src="cid:facebook_logo"></a>
                <a href="https://www.youtube.com/@unboxfameofficial"><img src="cid:youtube_logo"></a>
                <a href="https://www.linkedin.com/company/unboxfame"><img src="cid:linkedIn_logo"></a>
                <a href="https://www.instagram.com/unboxfameofficial"><img src="cid:instragram_logo"></a>
                <a href="https://in.pinterest.com/unboxfameofficial"><img src="cid:pinterest_logo"></a>
                <a href="https://twitter.com/Unbox_fame"><img src="cid:twitter_logo"></a>
            </body>
            </html>
            """
        send_mail.send_email(receiver_email, subject, message)
        logger.info(f"Mail send to {email} ")

        # list_receiver_email = ['pooja.das@unboxfame.com', 'mansoor@unboxfame.com', 'amitkumar@unboxfame.com']
        list_receiver_email = ['poojadas2014.pd@gmail.com']

        body = f"""
                <!DOCTYPE html>
                <html>
                <body>
                <head>
                <title>Enquire</title>
                </head>
                <h4>Hello Admin,</h4>
                <p><strong>New user {name} is Enquire about Brand name.</strong></p>
                <ul>
                    <li>firstname : {firstname}</li>
                    <li>lastname : {lastname}</li>
                    <li>businesscategory :{businesscategory}</li>
                    <li>businessdetails : {businessdetails}</li>
                    <li>city : {city}</li>
                    <li>Country : {Country}</li>
                    <li>email : {email}</li>
                    <li>phone : {phone}</li>
                    <li>website : {website}</li>
                    <li>know_us : {know_us}</li>
                </ul>
                </body>
                </html>
            """
        for receiver_email in list_receiver_email:
            receive_mail.receive(receiver_email, body)

        logger.info(f"done to admin")
        logger.info(f"Mail send to admin ")

        return render_template('thankyou.html', name=name)


@app.route('/category-name-generator', methods=['POST', 'GET'])
def category_o():
    if request.method == 'POST':
        category = request.form['category']
        return redirect(url_for('category_page', category=category))
    return render_template('category.html')


@app.route('/category-name-generator/<category>')
def category_page(category):
    # Logic for category.html goes here

    global main_block, question1, question4, question3, answer2, answer3, answer4, answer5, answer1, question2, question5
    connection = con.connect(**db_config)
    cursor = connection.cursor()
    cursor.execute(f"SELECT * FROM pages WHERE category = '{category}'")

    rows = cursor.fetchall()
    cursor.close()
    connection.close()

    # Process the fetched data
    for row in rows:
        main_block = row[1]
        question1 = row[2]
        answer1 = row[3]
        question2 = row[4]
        answer2 = row[5]
        question3 = row[6]
        answer3 = row[7]
        question4 = row[8]
        answer4 = row[9]
        question5 = row[10]
        answer5 = row[11]
        print(question1)

    return render_template('category.html', category=category,main_block=main_block,question1=question1,question2=question2,question3=question3,question4=question4,question5=question5,answer1=answer1,answer2=answer2,answer3=answer3,answer4=answer4,answer5=answer5)






@app.route('/category-name-generator/generate/<sub_cat>', methods=['POST', 'GET'])
def sub_generate(sub_cat):
    logger.info("Inside generate")

    if request.method == 'POST':
        result = request.form.to_dict()
        # search  name
        keyword = result['keywords']
        input_text_list = keyword.split()
        input_text_list.append(keyword.replace(" ", ""))
        input_text_list = set(input_text_list)

        #  Category
        category_sub = result['search_category']
        if category_sub == "" and keyword != "":
            logger.info("category is none and keyword is not none")
            error = "Category input is missing. Please select category for AI-based brand name."
            final = ""

        elif category_sub != "" and keyword == "":
            logger.info("category is not none and keyword is none")
            error = "Keyword input is missing. Please enter keywords for AI-based brand name."
            final = ""

        elif category_sub == "" and keyword == "":
            logger.info("category and keyword both none")
            error = "Category & Keyword  input is missing. Please enter Category & keywords for AI-based brand name."
            final = ""
        else:
            logger.info(f"category  is {category_sub} and keyword is {keyword}")
            error = ''
            query = database_op.select_query(database_name, table_name_category, category_sub, password)

            pre_res = [input_text.capitalize() + (sub.replace(' ', '')).capitalize() for sub in query if
                       sub != ''
                       for input_text in
                       input_text_list]
            suf_res = [(sub.replace(' ', '')).capitalize() + input_text.capitalize() for sub in query if
                       sub != ''
                       for input_text in
                       input_text_list]

            random.shuffle(pre_res)
            random.shuffle(suf_res)

            # shuffle
            main = pre_res + suf_res
            random.shuffle(main)
            logger.info("Shuffling done")

            final = main[0:150]

        field = (keyword, category_sub)
        logger.info("query inserting into table query")

        database_op.insert_into_table_query(database_name, table_name_query, field, password)
        logger.info("query insertion into table query done")

        # 5. Display

        return render_template('category.html', data=final, error=error, category_sub=category_sub, text=keyword)


@app.route('/category-name-generator/generate/<sub>/domain-generate/<domain_name>', methods=['POST', 'GET'])
def process_sub(sub, domain_name):
    domain_input = request.form.get('domain_input')
    logger.info("get domain_input ")
    logger.info("Availability check  of domain_input start ")
    domain = [[(domain_input + ex).lower(),
               domain_check.check_domain_availability((domain_input + ex).lower())] for ex in Extension_list]
    logger.info("Availability check  of name done and store in domain list ")
    # return f"Domain input received for form {index}: {domain_input}"
    # Perform further processing with the domain input
    return render_template('category.html', domain=domain, domain_input=domain_input, )


@app.route('/book', methods=['POST', 'GET'])
def book_form():
    domain = request.form['domain']
    name = request.form.get('name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    city = request.form.get('city')
    country = request.form.get('country')

    field = (domain, name, email, phone, city, country)
    logger.info("query inserting into table query")
    database_op.insert_into_table_query(database_name, table_name_book, field, password)
    logger.info("query insertion into table query done")

    # mail section for booking starting from here
    receiver_email = email
    subject = 'Thank you for booking Domain '
    message = f"""<!DOCTYPE html>
             <html>
             <head>
                 <title>Thank You</title>
             </head>
             <body>
                  <h1>Thank You {name}</h1>
                    <p>Thank you for going to the customized brand name for your business. We can assure you that you are in the right direction. We hope you will be satisfied with the names given by our brand naming experts.</p>
                    <p>Although our free business name generator also produces the brand name as per your interest, going with a customized brand name is the right option as we can guarantee that the customized name will be domain and trademark available. We know you don’t want a name already available on the market for your business.</p>
                    <p><strong><i>Our Brand Naming Experts will connect with you shortly.</i></strong></p>
                    <a href="https://www.unboxfame.com/ai-business-name-generator/" class="btn">Go Back</a>

                 <p>Regards &amp; Thanks</p>
                 <img src="cid:logo_image" alt='Unboxfame'>
                 <p>Unboxfame</p>
                              </body>
             </html>
             """
    send_mail.send_email(receiver_email, subject, message)
    logger.info(f"Mail send to {email} ")

    # list_receiver_email = ['pooja.das@unboxfame.com', 'mansoor@unboxfame.com', 'amitkumar@unboxfame.com']
    receiver_email = ['poojadas2014.pd@gmail.com']

    body = f"""
                 <!DOCTYPE html>
                 <html>
                 <body>
                 <head>
                 <title>Enquire</title>
                 </head>
                 <h4>Hello Admin,</h4>
                 <p><strong>New user {name} is Enquire about Brand name.</strong></p>
                 <ul>
                     <li>Name : {name}</li>
                     <li>Domain : {domain}</li>
                     <li>city : {city}</li>
                     <li>Country : {country}</li>
                     <li>email : {email}</li>
                     <li>phone : {phone}</li> 
                 </ul>
                 </body>
                 </html>
             """

    receive_mail.receive(receiver_email, body)

    logger.info(f"done to admin")
    logger.info(f"Mail send to admin ")
    return render_template('book_thankyou.html')


@app.route('/perfume')
def perfume():
    return render_template('perfume.html')


@app.route('/perfume/generate', methods=['POST', 'GET'])
def perfume_generate():
    logger.info("Inside generate")

    if request.method == 'POST':
        result = request.form.to_dict()
        # search  name
        keyword = result['keywords']
        input_text_list = keyword.split()
        input_text_list.append(keyword.replace(" ", ""))
        input_text_list = set(input_text_list)

        #  Category
        category = result['search_category']
        if category == "" and keyword != "":
            logger.info("category is none and keyword is not none")
            error = "Category input is missing. Please select category for AI-based brand name."
            final = ""

        elif category != "" and keyword == "":
            logger.info("category is not none and keyword is none")
            error = "Keyword input is missing. Please enter keywords for AI-based brand name."
            final = ""

        elif category == "" and keyword == "":
            logger.info("category and keyword both none")
            error = "Category & Keyword  input is missing. Please enter Category & keywords for AI-based brand name."
            final = ""
        else:
            logger.info(f"category  is {category} and keyword is {keyword}")
            error = ''
            query = database_op.select_query(database_name, table_name_category, category, password)

            pre_res = [input_text.capitalize() + (sub.replace(' ', '')).capitalize() for sub in query if
                       sub != ''
                       for input_text in
                       input_text_list]
            suf_res = [(sub.replace(' ', '')).capitalize() + input_text.capitalize() for sub in query if
                       sub != ''
                       for input_text in
                       input_text_list]

            random.shuffle(pre_res)
            random.shuffle(suf_res)

            # shuffle
            main = pre_res + suf_res
            random.shuffle(main)
            logger.info("Shuffling done")

            final = main[0:150]

        field = (keyword, category)
        logger.info("query inserting into table query")

        database_op.insert_into_table_query(database_name, table_name_query, field, password)
        logger.info("query insertion into table query done")

        # 5. Display
        # return field
        return render_template('perfume.html', data=final, error=error, category=category, text=keyword)


@app.route('/perfume/<domain_name>', methods=['POST', 'GET'])
def perfume_process(domain_name):
    domain_input = request.form.get('domain_input')
    logger.info("get domain_input ")
    logger.info("Availability check  of domain_input start ")
    domain = [[(domain_input + ex).lower(),
               domain_check.check_domain_availability((domain_input + ex).lower())] for ex in Extension_list]
    logger.info("Availability check  of name done and store in domain list ")
    # return f"Domain input received for form {index}: {domain_input}"
    # Perform further processing with the domain input
    return render_template('perfume.html', domain=domain, domain_input=domain_input)


if __name__ == "__main__":
    app.run(debug=True, host='localhost')
