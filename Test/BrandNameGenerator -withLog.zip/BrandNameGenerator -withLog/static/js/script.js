$(document).ready(function(){
$('#searchCategoryBtn').click(function(){
    $('.category-list-wrap').toggle();
});
});

$('#menuToggle').click(function(){
    $('.nav').toggle();
});



$(window).on("scroll", function() {
		$(window).scrollTop() ? $("header").addClass("sticky") : $("header").removeClass("sticky")
	});



	// filter function
$(document).ready(function() {

		  $('#search-input').keyup(function() {
			filterItems();
		  });

		  function filterItems() {

			var searchQuery = $('#search-input').val().toLowerCase();

			$('#item-list li').each(function() {
			  var itemText = $(this).text().toLowerCase();

			  if (

				(searchQuery === '' || itemText.includes(searchQuery))
			  ) {
				$(this).show();
			  } else {
				$(this).hide();
			  }
			});
		  }
		});


	// apply function
	 $(document).ready(function() {
		  $('.option').click(function() {
			$('.option').not(this).prop('checked', false); // Uncheck other checkboxes

			if ($(this).is(':checked')) {
			  $('#searchCategoryBtn').val($(this).val()); // Display value in text box
			   $(".category-list-wrap").hide(); //hidden
			} else {
			  $('#searchCategoryBtn').val(''); // Clear text box if unchecked
			}
		  });
		});

// copy-paste

function copyText(text, button) {
      var tempTextarea = document.createElement('textarea');
      tempTextarea.value = text;
      document.body.appendChild(tempTextarea);
      tempTextarea.select();
      document.execCommand('copy');
      document.body.removeChild(tempTextarea);

      button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5" /></svg>';

      setTimeout(function() {
        button.innerHTML = '<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path><rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect></svg>';
      }, 3000); // Revert back to "Copy" after 4 seconds
    }

// DOMAIN AVAILABLE SIDEBAR FUNCTION
		$('#checkDomainAvailibility').click(function(){
			$('#sidebarDomain').addClass('domain-sidebar-slide');
		});
		$('#sidebarclose').click(function(){
			$('#sidebarDomain').removeClass('domain-sidebar-slide');
		});



function toggleDiv(index) {
            var div = document.getElementById("div" + index);
            if (div.style.display === "none") {
                div.style.display = "block";
            } else {
                div.style.display = "none";
            }
        }


$('#cancelBtn').click(function(index) {
  $('#myDiv').hide();
});


// Add event listener to each cancel button
    var cancelBtns = document.querySelectorAll("[id^='cancelBtn']");
    cancelBtns.forEach(function(cancelBtn) {
        cancelBtn.addEventListener("click", function() {
            var divId = this.id.replace("cancelBtn", "div");
            var div = document.getElementById(divId);
            div.style.display = "none";
        });
    });
// Add event listener to each back button
    var backBtns = document.querySelectorAll("[id^='backBtn']");
    backBtns.forEach(function(backBtn) {
        backBtn.addEventListener("click", function() {
            var divId = this.id.replace("backBtn", "div");
            var div = document.getElementById(divId);
            div.style.display = "none";
        });
    });


// redirect by clicking go back
function redirectToNewPage() {
            // Redirect to the desired URL
            window.location.href = "http://localhost:5000/";

            // Hide the button after the redirection
            var buttonDiv = document.getElementById("button-div");
            buttonDiv.style.display = "none";
        }

// pop up
 var names = ['Alexander', 'Benjamin', 'Carlos', 'Daniel', 'Emmanuel', 'Felix', 'Gabriel', 'Hugo', 'Ivan', 'Javier', 'Klaus', 'Leonardo', 'Marco', 'Nathan', 'Oscar', 'Pablo', 'Rafael', 'Sebastian', 'Tobias', 'Victor', 'William', 'Xavier', 'Yannick', 'Zachary', 'Adrian', 'Bruno', 'Cristiano', 'Dante', 'Eduardo', 'Fernando', 'Gaston', 'Hector', 'Ignacio', 'Joaquin', 'Khalid', 'Luis', 'Miguel', 'Nicolas', 'Oliver', 'Paolo', 'Quentin', 'Ricardo', 'Santiago', 'Tomas', 'Ulises', 'Vincent', 'Wolfgang', 'Xavier', 'Youssef', 'Zoltan', 'Arjun', 'Devendra', 'Harish', 'Jai', 'Kunal', 'Manish', 'Nitin', 'Prakash', 'Rajesh', 'Sanjay', 'Aishwarya', 'Deepika', 'Ishita', 'Kavita', 'Meera', 'Nisha', 'Pooja', 'Radhika', 'Sanya', 'Tanvi', 'Amelia', 'Beatriz', 'Camila', 'Daniela', 'Elena', 'Fatima', 'Gabriela', 'Hanna', 'Isabella', 'Juliana', 'Karina', 'Laura', 'Maria', 'Natalia', 'Olivia', 'Paulina', 'Rafaela', 'Sofia', 'Valentina', 'Ximena', 'Yasmine', 'Zoe', 'Agnes', 'Bianca', 'Charlotte', 'Delphine', 'Esmeralda', 'Flavia', 'Giselle', 'Helena', 'Isadora', 'Jasmine', 'Kiara', 'Leticia', 'Mariana', 'Natasha', 'Olivia', 'Penelope', 'Regina', 'Sabrina', 'Tatiana', 'Ursula', 'Veronica', 'Wanda', 'Xiomara', 'Yara', 'Zara', 'Abigail', 'Bella', 'Claire'];
 var intervals = ["1 min","1 min","1 min","2 min", "2 min","3 min","3 min","4 min","4 min","5 min", "10 min", "15 min", "20 min",'30 min'];
 var services = ['Premium','Premium','Premium','Premium','AI Generated','Premium','Premium','Premium','Premium','Premium'];

 function showRandomPersonAndTime() {
    // names
    var randomNameIndex = Math.floor(Math.random() * names.length);
    var randomName = names[randomNameIndex];

    // intervals
    var randomIntervalIndex = Math.floor(Math.random() * intervals.length);
    var randomInterval = intervals[randomIntervalIndex];

    //services
    var randomServiceIndex = Math.floor(Math.random() * services.length);
    var randomService = services[randomServiceIndex];

    var content = document.getElementById("content");
    content.innerText = randomName + " took our  Premium "+ randomService + " service " + randomInterval + " ago.";

    setTimeout(showRandomPersonAndTime, 10000);
    }

 showRandomPersonAndTime();



// validation form

var formCards = document.querySelectorAll('.form-card');
        var progressItems = document.querySelectorAll('#progressbar li');
        var currentIndex = 0;

        function showCard(index) {
            formCards[currentIndex].classList.remove('show');
            progressItems[currentIndex].classList.remove('active');

            formCards[index].classList.add('show');
            progressItems[index].classList.add('active');

            currentIndex = index;
        }

        function validateFields() {
            var fields = formCards[currentIndex].querySelectorAll('input[required], textarea[required], select[required]');
            var isValid = true;

            fields.forEach(function (field) {
                if (field.value.trim() === '') {
                    field.classList.add('invalid');
                    isValid = false;
                } else {
                    field.classList.remove('invalid');
                }
            });

            if (!isValid) {
                progressItems[currentIndex].classList.add('error');
            } else {
                progressItems[currentIndex].classList.remove('error');
            }

            return isValid;
        }

        function validateContactDetails() {
            var emailField = document.querySelector('input[name="email"]');
            var phoneField = document.querySelector('input[name="phone"]');
            var isValid = true;

            if (emailField.value.trim() !== '' && !validateEmail(emailField.value)) {
                emailField.classList.add('invalid');
                isValid = false;
            } else {
                emailField.classList.remove('invalid');
            }

            if (phoneField.value.trim() !== '' && !validatePhone(phoneField.value)) {
                phoneField.classList.add('invalid');
                isValid = false;
            } else {
                phoneField.classList.remove('invalid');
            }

            if (!isValid) {
                progressItems[currentIndex].classList.add('error');
            } else {
                progressItems[currentIndex].classList.remove('error');
            }

            return isValid;
        }

        function validateEmail(email) {
            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }

function validatePhone(phone) {
    var phoneRegex = /^\+\d{1,4}[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}$/;

    if (!phoneRegex.test(phone)) {
        return "Invalid phone number.";
    }

    // Check if the phone number starts with a country code
    if (!phone.startsWith("+")) {
        return "Phone number should start with a country code.";
    }

    // Phone number is valid
    return true;
}

function handleNext() {
    if (!validateFields()) {
        return;
    }

    if (currentIndex === 2) {
        var phoneInput = document.getElementById("phoneInput");
        var phoneNumber = phoneInput.value;
        var phoneValidationResult = validatePhone(phoneNumber);
        var errorElement = document.getElementById("phoneError");

        if (phoneValidationResult !== true) {
            // Display the phone number validation error
            console.log(phoneValidationResult);

            // Apply red color to the field
            phoneInput.classList.add("invalid");

            // Display the error message
            errorElement.textContent = phoneValidationResult;
            return;
        } else {
            // Remove red color and error message if the validation passes
            phoneInput.classList.remove("invalid");
            errorElement.textContent = "";
        }
    }

    showCard(currentIndex + 1);
}

function handlePrevious() {
    showCard(currentIndex - 1);
}

var nextButtons = document.querySelectorAll('.next');
var previousButtons = document.querySelectorAll('.previous');

nextButtons.forEach(function (button) {
    button.addEventListener('click', handleNext);
});

previousButtons.forEach(function (button) {
    button.addEventListener('click', handlePrevious);
});


// book now pop up
 function showPop(domain) {
            document.getElementById('bookingPopup').style.display = 'block';
            document.getElementById('selectedDomain').value = domain;
        }


function redirectToPage(url) {
    window.location.href = url;
  }