import mysql.connector as con
import csv
from core import logger

logger = logger.create_logger("database_op")


def create_database(database_name, password):
    try:
        # connection
        mydb = con.connect(host='localhost',
                           user='root',
                           # user='unboabvo_ainame',
                           password=password)

        # creating cursor object
        # create a cursor to execute queries
        cur = mydb.cursor()  # cur just object name

        # create database
        cur.execute(f"CREATE DATABASE {database_name};")
        logger.info("Database %s successfully Created." % database_name)
        mydb.close()
    except Exception as e:
        logger.exception(str(e))
        logger.info("Database %s Already EXITED !!" % database_name)
        logger.info("Dropping.... Database %s" % database_name)
        cur.execute(f"DROP DATABASE {database_name};")
        logger.info("Database dropped successfully...")
        cur.execute(f"CREATE DATABASE {database_name};")
        logger.info("Database %s successfully Created." % database_name)
        mydb.close()


def connection_db(database_name, password):
    try:
        mydb = con.connect(host='localhost',
                           user='root',
                           password=password,
                           database=database_name)
        logger.info(f"Connected with database {database_name} established successfully...")
    except ConnectionError:
        logger.exception("Error while connecting to database: %s" % ConnectionError)
        raise ConnectionError
    return mydb


def create_table(database_name, table_name, password):
    logger.info('Start of Creating Table...')
    mydb = connection_db(database_name, password)

    query1 = f"""
    SET GLOBAL innodb_default_row_format='dynamic';
    SET SESSION innodb_strict_mode=OFF; 
    CREATE TABLE {table_name}(
                           Accountant VARCHAR(50),
                        Advertising VARCHAR(50),
                        Aerospace VARCHAR(50),
                        Agriculture VARCHAR(50),
                        ArtandCraft VARCHAR(50),
                        Automotive VARCHAR(50),
                        Bakery VARCHAR(50),
                        Beauty VARCHAR(50),
                        Boutique VARCHAR(50),
                        Cat VARCHAR(50),
                        Clothing VARCHAR(50),
                        Coffee_shop VARCHAR(50),
                        Communication VARCHAR(50),
                        Construction VARCHAR(50),
                        Corporate VARCHAR(50),
                        Cosmetic VARCHAR(50),
                        Dance VARCHAR(50),
                        Dog VARCHAR(50),
                        Education VARCHAR(50),
                        Entertainment VARCHAR(50),
                        Fashion VARCHAR(50),
                        Finance VARCHAR(50),
                        Fitness VARCHAR(50),
                        Food VARCHAR(50),
                        Footwear VARCHAR(50),
                        Furniture VARCHAR(50),
                        Gaming VARCHAR(50),
                        Health VARCHAR(50),
                        Interior_Design VARCHAR(50),
                        Jewellery VARCHAR(50),
                        Leather VARCHAR(50),
                        Luxury VARCHAR(50),
                        Marketing VARCHAR(50),
                        Media VARCHAR(50),
                        Music VARCHAR(50),
                        News VARCHAR(50),
                        Online_Gaming VARCHAR(50),
                        Perfume VARCHAR(50),
                        Pet_Shop VARCHAR(50),
                        Printing VARCHAR(50),
                        Real_Estate VARCHAR(50),
                        Shoes VARCHAR(50),
                        Skincare VARCHAR(50),
                        Sports VARCHAR(50),
                        Stitchcraft VARCHAR(50),
                        Tea_Shop VARCHAR(50),
                        Technology VARCHAR(50),
                        Travel VARCHAR(50),
                        Veterinary VARCHAR(50),
                        Wellness VARCHAR(50)
                        );"""

    query2 = f"""CREATE TABLE {table_name}(
                      Name VARCHAR(50),
                      Category VARCHAR(50)
                    );"""

    query3 = f"""CREATE TABLE {table_name}(
                      Firstname VARCHAR(50),
                      lastname VARCHAR(50),
                      businesscategory VARCHAR(100),
                      businessdetails VARCHAR(200),
                      city VARCHAR(50),
                      Country VARCHAR(50),
                      email VARCHAR(70),
                      phone VARCHAR(50),
                      website VARCHAR(100),
                      know_us VARCHAR(50)
                    );"""
    query4 = f"""CREATE TABLE {table_name}(
                          domain VARCHAR(50),
                          name VARCHAR(50),
                          email VARCHAR(70),
                          phone VARCHAR(50),
                          city VARCHAR(50),
                          country VARCHAR(50)
                        );"""
    if table_name == "category":
        logger.info(f'Table creating for {table_name}')
        try:
            cur = mydb.cursor()
            cur.execute(query1)
            logger.info(f'Table created for {table_name}')
            mydb.close()
        except:
            logger.info(f"Table  {table_name} Exit")
            cur.execute(f"Drop table {table_name}")
            logger.info(f'Table  {table_name} drop')
            cur.execute(query1)
            logger.info(f'Table created for {table_name}')
            mydb.close()

    elif table_name == "Enquire":
        logger.info(f'Table creating for {table_name}')
        try:
            cur = mydb.cursor()
            cur.execute(query3)
            logger.info(f'Table created for {table_name}')
            mydb.close()
        except:
            logger.info(f"Table  {table_name} Exit")
            cur.execute(f"Drop table {table_name}")
            logger.info(f'Table  {table_name} drop')
            cur.execute(query3)
            logger.info(f'Table created for {table_name}')
            mydb.close()

    elif table_name =="Domain_Enquire":
        logger.info(f'Table creating for {table_name}')
        try:
            cur = mydb.cursor()
            cur.execute(query4)
            logger.info(f'Table created for {table_name}')
            mydb.close()
        except:
            logger.info(f"Table  {table_name} Exit")
            cur.execute(f"Drop table {table_name}")
            logger.info(f'Table  {table_name} drop')
            cur.execute(query4)
            logger.info(f'Table created for {table_name}')
            mydb.close()

    else:
        logger.info(f'Table creating for {table_name}')
        try:
            cur = mydb.cursor()
            cur.execute(query2)
            logger.info(f'Table created for {table_name}')
            mydb.close()
        except:
            logger.info(f"Table  {table_name} Exit")
            execute(f"Drop table {table_name}")
            logger.info(f'Table  {table_name} drop')
            cur.execute(query2)
            logger.info(f'Table created for {table_name}')
            mydb.close()


def insert_into_table_category(database_name, table_name, password):
    logger.info(f'Inserting start on table {table_name}')
    file = "category.csv"
    mydb = connection_db(database_name, password)

    with open(file) as csv_file:
        csvfile = csv.reader(csv_file, delimiter=',')
        data = [tuple(row) for row in csvfile]
        for row in data[1:]:
            query = f"INSERT INTO {table_name} VALUES {row}"
            cur = mydb.cursor()
            cur.execute(query)
            mydb.commit()
    logger.info(f"Insertion done on table {table_name} ")


def insert_into_table_query(database_name, table_name, field, password):
    logger.info(f'Inserting start on table {table_name}')
    mydb = connection_db(database_name, password)

    query = f"INSERT INTO {table_name} VALUES {field}"
    cur = mydb.cursor()
    cur.execute(query)
    mydb.commit()
    logger.info(f"Insertion done on table {table_name} ")


def insert_into_table_enquire(database_name, table_name, field, password):
    logger.info(f"Inserting Done on table {table_name} ")
    mydb = connection_db(database_name, password)

    query = f"INSERT INTO {table_name} VALUES {field}"
    cur = mydb.cursor()
    cur.execute(query)
    mydb.commit()
    logger.info(f"Insertion done on table {table_name} ")


def select_query(database_name, table_name, col, password):
    logger.info(f"Selection start table {table_name} ")
    mydb = connection_db(database_name, password)
    query = f"select {col} from {table_name};"
    cur = mydb.cursor()
    cur.execute(query)
    result = cur.fetchall()
    record = [j for i in result for j in i]
    logger.info(f"Selection done table {table_name} ")
    return record

database_name = 'UnboxfameData'
password = ""
table_name = "category"
# table_name = "query_file"
# table_name = "Enquire"
# table_name = "Domain_Enquire"

# create_database(database_name, password)
# create_table(database_name, table_name, password)
# insert_into_table_category(database_name, table_name, password)
#
# p = select_query(database_name, table_name, '*', password)
# print(p)
