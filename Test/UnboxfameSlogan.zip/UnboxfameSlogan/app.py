import random
from flask import Flask, render_template, request, redirect, url_for
import mysql.connector as con

db_config = {
    'host': 'localhost',
    'database': 'Unboxfamedata',
    'user': 'root',
    'password': ''
}


def AllSologan():
    connection = con.connect(**db_config)
    cursor = connection.cursor()
    select_query = f'SELECT Slogan FROM slogan'
    cursor.execute(select_query)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    return result


# Object for Flask
app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/generate', methods=['POST', 'GET'])
def generate():
    if request.method == 'POST':
        result = request.form.to_dict()
        # search  name
        keyword = result['keywords']

        #  Category

        if keyword == "":
            error = "Keyword input is missing. Please enter keywords for AI-based brand name."
            data = None
            keyword =None
        else:

            pre_res = [sub.replace('{keyword}', keyword.capitalize()) for solo in AllSologan() if solo != '' for sub in
                       solo]
            error = None

            random.shuffle(pre_res)

            # shuffle
            data = pre_res
            random.shuffle(data)
            keyword=keyword

        # return field
        return render_template('index.html', data=data, error=error, keyword=keyword)


if __name__ == "__main__":
    app.run(debug=True, host='localhost')
